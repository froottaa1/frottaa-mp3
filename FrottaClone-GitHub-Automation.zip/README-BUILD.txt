# Frotta Clone GitHub build helper

Upload `FrottaClone.zip` to the repository root and add the workflow file at:

`.github/workflows/android-build.yml`

Then open the repository's **Actions** tab and run **Build Frotta Clone APK**.
The workflow extracts the archive, finds the Gradle project, runs `assembleDebug`,
and publishes the APK as a downloadable artifact named `Frotta-Clone-debug-APK`.

The workflow requires a valid Android Gradle project in the ZIP. It does not repair
source-code or dependency errors; failed builds show their diagnostic output in Actions.
