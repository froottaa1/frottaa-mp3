package com.frotta.files;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.*;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.Holder> {
    public interface Listener { void open(File file); default void selectionChanged(){} }
    private final List<File> files = new ArrayList<>();
    private final Set<File> selected = new LinkedHashSet<>();
    private final Listener listener;
    private boolean selectionMode = false;
    public FileAdapter(Listener l) { listener=l; setHasStableIds(false); }
    public void submit(List<File> data) { files.clear(); files.addAll(data); selected.retainAll(files); notifyDataSetChanged(); }
    public void setSelectionMode(boolean enabled) { selectionMode=enabled; if(!enabled) selected.clear(); notifyDataSetChanged(); }
    public boolean isSelectionMode(){return selectionMode;}
    public Set<File> getSelected(){return new LinkedHashSet<>(selected);}
    public void selectAll(){ selected.clear(); selected.addAll(files); selectionMode=true; notifyDataSetChanged(); }
    public void clearSelection(){selected.clear();selectionMode=false;notifyDataSetChanged();}
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup p,int t){return new Holder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_file,p,false));}
    @Override public void onBindViewHolder(@NonNull Holder h,int pos){
        File f=files.get(pos); h.name.setText(f.getName());
        h.info.setText(f.isDirectory()?"مجلد • "+(f.list()==null?0:f.list().length)+" عنصر":android.text.format.Formatter.formatFileSize(h.itemView.getContext(),f.length()));
        h.icon.setText(f.isDirectory()?"📁":iconFor(f)); h.check.setVisibility(selectionMode?View.VISIBLE:View.GONE);
        h.check.setOnCheckedChangeListener(null); h.check.setChecked(selected.contains(f));
        h.itemView.setOnClickListener(v->{if(selectionMode)toggle(f);else listener.open(f);});
        h.check.setOnCheckedChangeListener((b,c)->{if(c)selected.add(f);else selected.remove(f);listener.selectionChanged();});
        h.itemView.setOnLongClickListener(v->{if(!selectionMode){selectionMode=true;selected.add(f);notifyDataSetChanged();listener.selectionChanged();}return true;});
    }
    private String iconFor(File f){String n=f.getName().toLowerCase(Locale.ROOT);if(n.endsWith(".apk"))return"📦";if(n.endsWith(".zip"))return"🗜";if(n.matches(".*\\.(jpg|jpeg|png|gif|webp)$"))return"🖼";if(n.matches(".*\\.(mp3|wav|m4a|ogg)$"))return"🎵";if(n.matches(".*\\.(mp4|mkv|3gp|mov)$"))return"🎬";return"📄";}
    private void toggle(File f){if(!selected.add(f))selected.remove(f);notifyDataSetChanged();listener.selectionChanged();}
    @Override public int getItemCount(){return files.size();}
    static class Holder extends RecyclerView.ViewHolder { TextView name,info,icon; CheckBox check; Holder(View v){super(v);name=v.findViewById(R.id.fileName);info=v.findViewById(R.id.fileInfo);icon=v.findViewById(R.id.fileIcon);check=v.findViewById(R.id.check);} }
}
