package com.frotta.files;

import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import java.util.*;

public class AppsActivity extends AppCompatActivity {
    private final List<ApplicationInfo> apps=new ArrayList<>(); private final Set<String> selected=new LinkedHashSet<>(); private final Queue<String> uninstallQueue=new ArrayDeque<>(); private TextView count;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_apps);count=findViewById(R.id.appsCount);RecyclerView rv=findViewById(R.id.appsList);rv.setLayoutManager(new LinearLayoutManager(this));loadApps();rv.setAdapter(new AppsAdapter());findViewById(R.id.uninstallButton).setOnClickListener(v->beginUninstall());}
    private void loadApps(){PackageManager pm=getPackageManager();apps.clear();for(ApplicationInfo ai:pm.getInstalledApplications(PackageManager.GET_META_DATA)){if(!ai.packageName.equals(getPackageName()))apps.add(ai);}apps.sort((a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));count.setText("عدد التطبيقات: "+apps.size()+" • المحدد: "+selected.size());}
    private void beginUninstall(){if(selected.isEmpty()){Toast.makeText(this,"حدد تطبيقاً واحداً على الأقل",Toast.LENGTH_SHORT).show();return;}new MaterialAlertDialogBuilder(this).setTitle("إلغاء تثبيت التطبيقات").setMessage("سيعرض أندرويد شاشة تأكيد منفصلة لكل تطبيق. لن يتم حذف أي تطبيق دون موافقتك.").setPositiveButton("متابعة",(d,w)->{uninstallQueue.clear();uninstallQueue.addAll(selected);requestNext();}).setNegativeButton("إلغاء",null).show();}
    private void requestNext(){String pkg=uninstallQueue.poll();if(pkg==null){selected.clear();loadApps();((RecyclerView)findViewById(R.id.appsList)).getAdapter().notifyDataSetChanged();Toast.makeText(this,"انتهت طلبات إلغاء التثبيت",Toast.LENGTH_LONG).show();return;}try{Intent i=new Intent(Intent.ACTION_DELETE, Uri.parse("package:"+pkg));startActivityForResult(i,71);}catch(Exception e){requestNext();}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==71){requestNext();}}
    private class AppsAdapter extends RecyclerView.Adapter<AppsAdapter.H>{@NonNull @Override public H onCreateViewHolder(@NonNull ViewGroup p,int t){return new H(LayoutInflater.from(p.getContext()).inflate(R.layout.item_app,p,false));}@Override public void onBindViewHolder(@NonNull H h,int pos){ApplicationInfo ai=apps.get(pos);PackageManager pm=getPackageManager();h.name.setText(pm.getApplicationLabel(ai));h.pkg.setText(ai.packageName);try{h.icon.setImageDrawable(pm.getApplicationIcon(ai));}catch(Exception ignored){}h.check.setOnCheckedChangeListener(null);h.check.setChecked(selected.contains(ai.packageName));h.check.setOnCheckedChangeListener((b,c)->{if(c)selected.add(ai.packageName);else selected.remove(ai.packageName);count.setText("عدد التطبيقات: "+apps.size()+" • المحدد: "+selected.size());});h.itemView.setOnClickListener(v->h.check.setChecked(!h.check.isChecked()));}@Override public int getItemCount(){return apps.size();}class H extends RecyclerView.ViewHolder{CheckBox check;ImageView icon;TextView name,pkg;H(View v){super(v);check=v.findViewById(R.id.appCheck);icon=v.findViewById(R.id.appIcon);name=v.findViewById(R.id.appName);pkg=v.findViewById(R.id.packageName);}}}
}
