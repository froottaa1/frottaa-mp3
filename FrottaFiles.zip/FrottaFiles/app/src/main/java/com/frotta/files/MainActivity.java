package com.frotta.files;

import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import java.io.*;
import java.util.*;

public class MainActivity extends AppCompatActivity implements FileAdapter.Listener {
    private File current=Environment.getExternalStorageDirectory();
    private FileAdapter adapter; private TextView path; private View selectionBar,selectionScroll; private boolean grid=false,showHidden=false;
    private String query=""; private int sortMode=0; private final List<File> pendingTransfer=new ArrayList<>(); private boolean pendingMove=false; private final Set<String> favorites=new LinkedHashSet<>();
    private static final String PREFS="frotta_preferences",FAVS="favorites";
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
        path=findViewById(R.id.pathText);selectionBar=findViewById(R.id.selectionBar);selectionScroll=findViewById(R.id.selectionScroll);
        RecyclerView list=findViewById(R.id.fileList);adapter=new FileAdapter(this);list.setLayoutManager(new LinearLayoutManager(this));list.setAdapter(adapter);
        favorites.addAll(getSharedPreferences(PREFS,MODE_PRIVATE).getStringSet(FAVS,new HashSet<>()));
        findViewById(R.id.appsButton).setOnClickListener(v->startActivity(new Intent(this,AppsActivity.class)));
        findViewById(R.id.upButton).setOnClickListener(v->goUp());
        findViewById(R.id.viewButton).setOnClickListener(v->{grid=!grid;list.setLayoutManager(grid?new GridLayoutManager(this,2):new LinearLayoutManager(this));});
        findViewById(R.id.selectButton).setOnClickListener(v->{if(adapter.isSelectionMode())adapter.clearSelection();else adapter.setSelectionMode(true);updateSelectionBar();});
        findViewById(R.id.selectAllButton).setOnClickListener(v->{adapter.selectAll();updateSelectionBar();});
        findViewById(R.id.copyButton).setOnClickListener(v->prepareTransfer(false));findViewById(R.id.moveButton).setOnClickListener(v->prepareTransfer(true));findViewById(R.id.pasteButton).setOnClickListener(v->executeTransfer());
        findViewById(R.id.deleteButton).setOnClickListener(v->deleteSelected());findViewById(R.id.zipButton).setOnClickListener(v->zipSelected());
        findViewById(R.id.moreButton).setOnClickListener(v->showMoreMenu());
        findViewById(R.id.newFolderButton).setOnClickListener(v->createItem(true));findViewById(R.id.newFileButton).setOnClickListener(v->createItem(false));
        findViewById(R.id.favoritesButton).setOnClickListener(v->showFavorites());
        findViewById(R.id.searchInput).setOnEditorActionListener((v,id,event)->{query=v.getText()==null?"":v.getText().toString().trim();refresh();return false;});
        ((android.widget.EditText)findViewById(R.id.searchInput)).addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString().trim();refresh();}public void afterTextChanged(Editable e){}});
        if(Build.VERSION.SDK_INT>=30&&!Environment.isExternalStorageManager())showPermissionDialog();else refresh();
    }
    private void showPermissionDialog(){new MaterialAlertDialogBuilder(this).setTitle(R.string.permission_title).setMessage(R.string.permission_message).setPositiveButton("فتح الإعدادات",(d,w)->{try{Intent i=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));}}).setNegativeButton("لاحقاً",null).show();}
    @Override protected void onResume(){super.onResume();if(Build.VERSION.SDK_INT<30||Environment.isExternalStorageManager())refresh();}
    private void refresh(){if(path==null)return;path.setText(current.getAbsolutePath());File[] a=current.listFiles();List<File> data=new ArrayList<>();if(a!=null)for(File f:a){if(!showHidden&&f.isHidden())continue;if(!query.isEmpty()&&!f.getName().toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT)))continue;data.add(f);}final int sm=sortMode;data.sort((x,y)->{if(x.isDirectory()!=y.isDirectory())return x.isDirectory()?-1:1;switch(sm){case 1:return Long.compare(y.lastModified(),x.lastModified());case 2:return Long.compare(x.length(),y.length());case 3:return Long.compare(y.length(),x.length());default:return x.getName().compareToIgnoreCase(y.getName());}});adapter.submit(data);updateSelectionBar();}
    private void goUp(){File p=current.getParentFile();if(p!=null&&p.canRead()){current=p;query="";((EditText)findViewById(R.id.searchInput)).setText("");refresh();}}
    @Override public void selectionChanged(){updateSelectionBar();}
    @Override public void open(File f){if(f.isDirectory()){current=f;query="";((EditText)findViewById(R.id.searchInput)).setText("");refresh();return;}if(f.getName().toLowerCase(Locale.ROOT).endsWith(".zip")){new MaterialAlertDialogBuilder(this).setMessage("فك ضغط الملف داخل المجلد الحالي؟").setPositiveButton("فك الضغط",(d,w)->{try{FileOps.unzip(f,current);refresh();toast("تم فك الضغط");}catch(Exception e){toast(e.getMessage());}}).setNegativeButton("إلغاء",null).show();return;}String mime=getMime(f);try{Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",f);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){toast("لا يوجد تطبيق مناسب لفتح هذا الملف");}}
    private String getMime(File f){String n=f.getName().toLowerCase(Locale.ROOT);if(n.endsWith(".apk"))return"application/vnd.android.package-archive";if(n.endsWith(".pdf"))return"application/pdf";if(n.matches(".*\\.(jpg|jpeg)$"))return"image/jpeg";if(n.endsWith(".png"))return"image/png";if(n.endsWith(".mp4"))return"video/mp4";if(n.endsWith(".mp3"))return"audio/mpeg";if(n.endsWith(".txt"))return"text/plain";return"*/*";}
    private void prepareTransfer(boolean move){Set<File> chosen=adapter.getSelected();if(chosen.isEmpty()){toast("حدد عناصر أولاً");return;}pendingTransfer.clear();pendingTransfer.addAll(chosen);pendingMove=move;adapter.clearSelection();updateSelectionBar();toast(move?"تم تجهيز العناصر للنقل. انتقل إلى المجلد الهدف واضغط لصق":"تم تجهيز العناصر للنسخ. انتقل إلى المجلد الهدف واضغط لصق");}
    private void executeTransfer(){if(pendingTransfer.isEmpty()){toast("لا توجد عناصر جاهزة للصق");return;}new MaterialAlertDialogBuilder(this).setMessage((pendingMove?"نقل":"نسخ")+" "+pendingTransfer.size()+" عنصر إلى "+current.getAbsolutePath()+"؟").setPositiveButton("لصق",(d,w)->{int ok=0;for(File f:new ArrayList<>(pendingTransfer)){try{File dest=new File(current,f.getName());if(f.getCanonicalFile().equals(dest.getCanonicalFile()))continue;if(dest.getCanonicalPath().startsWith(f.getCanonicalPath()+File.separator))throw new IOException("لا يمكن النقل داخل المجلد نفسه");if(pendingMove)FileOps.move(f,dest);else FileOps.copy(f,dest);ok++;}catch(Exception e){toast(e.getMessage());}}pendingTransfer.clear();toast("اكتملت العملية: "+ok+" عنصر");refresh();}).setNegativeButton("إلغاء",null).show();}
    private void deleteSelected(){Set<File>s=adapter.getSelected();if(s.isEmpty())return;new MaterialAlertDialogBuilder(this).setMessage("حذف "+s.size()+" عنصر؟ لا يمكن التراجع عن ذلك.").setPositiveButton("حذف",(d,w)->{for(File f:s)try{FileOps.delete(f);}catch(Exception e){toast(e.getMessage());}adapter.clearSelection();refresh();}).setNegativeButton("إلغاء",null).show();}
    private void zipSelected(){Set<File>s=adapter.getSelected();if(s.isEmpty())return;String name="Frotta_Archive_"+System.currentTimeMillis()+".zip";try{FileOps.zip(new ArrayList<>(s),new File(current,name));adapter.clearSelection();refresh();toast("تم إنشاء "+name);}catch(Exception e){toast(e.getMessage());}}
    private void createItem(boolean folder){EditText input=new EditText(this);input.setSingleLine(true);input.setHint(folder?"اسم المجلد":"اسم الملف مع الامتداد");new MaterialAlertDialogBuilder(this).setTitle(folder?"إنشاء مجلد":"إنشاء ملف").setView(input).setPositiveButton("إنشاء",(d,w)->{String n=input.getText().toString().trim();if(n.isEmpty()||n.contains("/")||n.contains("\\")){toast("اسم غير صالح");return;}File f=new File(current,n);try{boolean ok=folder?f.mkdirs():f.createNewFile();if(!ok)toast("الاسم موجود أو تعذر الإنشاء");refresh();}catch(Exception e){toast(e.getMessage());}}).setNegativeButton("إلغاء",null).show();}
    private void showMoreMenu(){String[] options={"إعادة تسمية المحدد","تفاصيل المحدد","مشاركة المحدد","إضافة/إزالة من المفضلة","إظهار/إخفاء الملفات المخفية","ترتيب الملفات","تحديث"};new MaterialAlertDialogBuilder(this).setTitle("المزيد").setItems(options,(d,w)->{switch(w){case 0:renameSelected();break;case 1:detailsSelected();break;case 2:shareSelected();break;case 3:toggleFavorite();break;case 4:showHidden=!showHidden;refresh();break;case 5:chooseSort();break;case 6:refresh();break;}}).show();}
    private void renameSelected(){Set<File>s=adapter.getSelected();if(s.size()!=1){toast("حدد عنصراً واحداً لإعادة تسميته");return;}File old=s.iterator().next();EditText input=new EditText(this);input.setSingleLine(true);input.setText(old.getName());new MaterialAlertDialogBuilder(this).setTitle("إعادة تسمية").setView(input).setPositiveButton("حفظ",(d,w)->{String n=input.getText().toString().trim();if(n.isEmpty()||n.contains("/")||n.contains("\\")){toast("اسم غير صالح");return;}File dest=new File(old.getParentFile(),n);if(dest.exists()||!old.renameTo(dest))toast("تعذرت إعادة التسمية");adapter.clearSelection();refresh();}).setNegativeButton("إلغاء",null).show();}
    private void detailsSelected(){Set<File>s=adapter.getSelected();if(s.size()!=1){toast("حدد عنصراً واحداً لعرض التفاصيل");return;}File f=s.iterator().next();String msg="الاسم: "+f.getName()+"\nالمسار: "+f.getAbsolutePath()+"\nالنوع: "+(f.isDirectory()?"مجلد":"ملف")+"\nالحجم: "+android.text.format.Formatter.formatFileSize(this,f.isDirectory()?folderSize(f):f.length())+"\nآخر تعديل: "+new Date(f.lastModified());new MaterialAlertDialogBuilder(this).setTitle("التفاصيل").setMessage(msg).setPositiveButton("إغلاق",null).show();}
    private long folderSize(File f){long total=0;File[] a=f.listFiles();if(a!=null)for(File x:a)total+=x.isDirectory()?folderSize(x):x.length();return total;}
    private void shareSelected(){Set<File>s=adapter.getSelected();if(s.isEmpty())return;ArrayList<Uri> uris=new ArrayList<>();for(File f:s)if(f.isFile())uris.add(FileProvider.getUriForFile(this,getPackageName()+".provider",f));if(uris.isEmpty()){toast("المشاركة متاحة للملفات فقط");return;}Intent i=new Intent(Intent.ACTION_SEND_MULTIPLE);i.setType("*/*");i.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"مشاركة الملفات"));}
    private void toggleFavorite(){Set<File>s=adapter.getSelected();if(s.isEmpty()){toast("حدد عنصراً أولاً");return;}for(File f:s){String p=f.getAbsolutePath();if(!favorites.add(p))favorites.remove(p);}getSharedPreferences(PREFS,MODE_PRIVATE).edit().putStringSet(FAVS,new HashSet<>(favorites)).apply();toast("تم تحديث المفضلة");}
    private void showFavorites(){List<String> valid=new ArrayList<>();for(String p:favorites)if(new File(p).exists())valid.add(p);if(valid.isEmpty()){toast("قائمة المفضلة فارغة");return;}String[] labels=new String[valid.size()];for(int i=0;i<valid.size();i++)labels[i]=new File(valid.get(i)).getName();new MaterialAlertDialogBuilder(this).setTitle("المفضلة").setItems(labels,(d,w)->{File f=new File(valid.get(w));if(f.isDirectory()){current=f;refresh();}else open(f);}).setNegativeButton("إغلاق",null).show();}
    private void chooseSort(){String[] a={"الاسم","الأحدث أولاً","الأصغر حجماً","الأكبر حجماً"};new MaterialAlertDialogBuilder(this).setTitle("ترتيب حسب").setSingleChoiceItems(a,sortMode,(d,w)->{sortMode=w;d.dismiss();refresh();}).setNegativeButton("إلغاء",null).show();}
    private void updateSelectionBar(){if(selectionScroll!=null)selectionScroll.setVisibility(adapter!=null&&adapter.isSelectionMode()?View.VISIBLE:View.GONE);}
    private void toast(String s){Toast.makeText(this,s==null?"حدث خطأ":s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){if(adapter!=null&&adapter.isSelectionMode()){adapter.clearSelection();updateSelectionBar();return;}if(current.getParentFile()!=null){goUp();}else super.onBackPressed();}
}
