package com.frotta.files;

import java.io.*;
import java.util.*;
import java.util.zip.*;

public final class FileOps {
    private FileOps(){}
    public static void copy(File source,File target)throws IOException{
        if(source.getCanonicalFile().equals(target.getCanonicalFile()))throw new IOException("المصدر والوجهة متطابقان");
        if(source.isDirectory()){
            if(target.getCanonicalPath().startsWith(source.getCanonicalPath()+File.separator))throw new IOException("لا يمكن نسخ مجلد داخل نفسه");
            if(!target.exists()&&!target.mkdirs())throw new IOException("تعذر إنشاء المجلد: "+target);
            File[] children=source.listFiles();if(children==null)throw new IOException("تعذر قراءة المجلد: "+source);
            for(File c:children)copy(c,new File(target,c.getName()));
        }else{
            File parent=target.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new IOException("تعذر إنشاء المجلد الأب");
            try(InputStream in=new BufferedInputStream(new FileInputStream(source));OutputStream out=new BufferedOutputStream(new FileOutputStream(target))){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
            if(source.lastModified()>0)target.setLastModified(source.lastModified());
        }
    }
    public static void move(File source,File target)throws IOException{if(!source.renameTo(target)){copy(source,target);delete(source);}}
    public static void delete(File f)throws IOException{if(f.isDirectory()){File[] a=f.listFiles();if(a==null)throw new IOException("تعذر قراءة المجلد: "+f);for(File c:a)delete(c);}if(!f.delete())throw new IOException("تعذر حذف: "+f.getAbsolutePath());}
    public static void zip(List<File> sources,File destination)throws IOException{
        String base=commonParent(sources);
        try(ZipOutputStream zos=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(destination)))){for(File f:sources)addZip(f,relativeName(f,base),zos);}
    }
    private static String commonParent(List<File> files){if(files.isEmpty())return"";File p=files.get(0).getParentFile();while(p!=null){boolean all=true;for(File f:files)if(!f.getAbsolutePath().startsWith(p.getAbsolutePath()+File.separator)){all=false;break;}if(all)return p.getAbsolutePath();p=p.getParentFile();}return"";}
    private static String relativeName(File f,String base){String p=f.getAbsolutePath();if(!base.isEmpty()&&p.startsWith(base+File.separator))p=p.substring(base.length()+1);return p;}
    private static void addZip(File f,String name,ZipOutputStream zos)throws IOException{
        if(f.isDirectory()){File[] a=f.listFiles();if(a==null)throw new IOException("تعذر قراءة: "+f);if(a.length==0){zos.putNextEntry(new ZipEntry(name+"/"));zos.closeEntry();}else for(File c:a)addZip(c,name+"/"+c.getName(),zos);}
        else{zos.putNextEntry(new ZipEntry(name));try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)zos.write(b,0,n);}zos.closeEntry();}
    }
    public static void unzip(File archive,File destination)throws IOException{
        String root=destination.getCanonicalPath()+File.separator;try(ZipInputStream zis=new ZipInputStream(new BufferedInputStream(new FileInputStream(archive)))){ZipEntry e;byte[] b=new byte[65536];while((e=zis.getNextEntry())!=null){File out=new File(destination,e.getName());String canonical=out.getCanonicalPath();if(!canonical.startsWith(root))throw new IOException("تم رفض مسار غير آمن داخل ZIP");if(e.isDirectory()){if(!out.mkdirs()&&!out.isDirectory())throw new IOException("تعذر إنشاء المجلد");}else{File p=out.getParentFile();if(p!=null&&!p.exists()&&!p.mkdirs())throw new IOException("تعذر إنشاء المجلد الأب");try(OutputStream os=new BufferedOutputStream(new FileOutputStream(out))){int n;while((n=zis.read(b))!=-1)os.write(b,0,n);}}zis.closeEntry();}}
    }
}
