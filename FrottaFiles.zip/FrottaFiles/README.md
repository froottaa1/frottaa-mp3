# Frotta Files — Android File Manager

Native Android application written in Java with AndroidX, Material 3 and XML layouts. Package: `com.frotta.files`.

## Build APK directly from GitHub (phone-friendly)

This repository includes `.github/workflows/android.yml` so you do **not** need Android Studio or a local Gradle installation to produce the APK.

1. Upload the complete contents of this project folder to a new GitHub repository. Keep the `.github/workflows/android.yml` file and its folders; do not upload only the Java files.
2. Open the repository on GitHub in your mobile browser or app.
3. Open **Actions** → **Build Frotta Files APK**.
4. Tap **Run workflow** (or wait for the first push build to finish).
5. Open the completed workflow run, scroll to **Artifacts**, and download `Frotta-Files-debug-apk`.
6. Extract the downloaded artifact ZIP; install `app-debug.apk` on your Android phone. You may need to allow installation from that browser/file manager.

Every push to `main` or `master` also triggers a build. The workflow uses JDK 17, Gradle 8.13, Android SDK 36 and Android Gradle Plugin 8.13.2.

## Features

- Material 3 black-and-gold user interface and Arabic labels.
- Internal/shared-storage browsing with path display and parent navigation.
- List/grid display, live filtering in the current directory, sort by name/date/size.
- Multi-select, select all, recursive copy/move/delete, ZIP creation and safe ZIP extraction.
- Create folders and files, rename, file details, share, hidden-file visibility and favorites.
- Installed-app listing and queued Android uninstall confirmation intents.
- File opening through Android intents and FileProvider.
- No FTP or SMB code or dependencies.

## Platform limitations and permissions

- Android 11+ requires the user to manually grant **All files access** in system settings. Android still restricts certain protected app-private locations.
- Android requires a separate system confirmation for each ordinary app uninstall. This app cannot silently uninstall apps and does not bypass device-owner or enterprise policy.
- `QUERY_ALL_PACKAGES` and `MANAGE_EXTERNAL_STORAGE` are sensitive permissions. Google Play distribution requires an eligible core use case and approval; sideloading/testing is separate from Play approval.
- File operations currently use the shared-storage filesystem API and therefore depend on the All files access permission. SAF support for arbitrary provider/document-tree locations is not implemented.
- Search filters the currently open directory (not a recursive whole-device index). Favorites store filesystem paths on this device.
- Batch file operations are synchronous; avoid selecting very large folders on low-memory devices. Test destructive operations on disposable data first.

## Project

- `app/src/main/java/com/frotta/files/` — Java application code
- `app/src/main/res/layout/` — XML layouts
- `app/src/main/res/values/` — colors, strings and Material theme
- `.github/workflows/android.yml` — cloud build workflow
