package com.frotta.mp3.ui

import android.graphics.Bitmap
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frotta.mp3.ArtLoader
import com.frotta.mp3.R
import com.frotta.mp3.Song

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun Ic(@DrawableRes id: Int, tint: Color = Color.White, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Icon(painterResource(id), contentDescription = null, tint = tint, modifier = modifier.size(size))
}

/** Text that always sits on its own rounded background. */
@Composable
fun Pill(
    text: String,
    modifier: Modifier = Modifier,
    bg: Color = Color.Black.copy(alpha = 0.45f),
    color: Color = Color.White,
    size: TextUnit = 11.sp
) {
    Text(
        text,
        color = color,
        fontSize = size,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier
            .background(bg, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun CircleBtn(
    @DrawableRes icon: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 22.dp,
    bg: Color = Color.Black.copy(alpha = 0.35f),
    tint: Color = Color.White,
    brush: Brush? = null
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(brush ?: Brush.linearGradient(listOf(bg, bg)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Ic(icon, tint, iconSize)
    }
}

private val placeholderPalettes = listOf(
    listOf(Color(0xFFFF8A3D), Color(0xFFFF3D81)),
    listOf(Color(0xFF8B5CF6), Color(0xFF3B82F6)),
    listOf(Color(0xFF10B981), Color(0xFF3B82F6)),
    listOf(Color(0xFFF43F5E), Color(0xFF8B5CF6)),
    listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
)

@Composable
fun SongArt(
    song: Song?,
    modifier: Modifier = Modifier,
    px: Int = 256,
    shape: Shape = RoundedCornerShape(14.dp)
) {
    val context = LocalContext.current
    val bmp by produceState<Bitmap?>(null, song?.id, px) {
        value = if (song == null) null else ArtLoader.load(context, song, px)
    }
    val seed = Math.floorMod((song?.title ?: "").hashCode(), placeholderPalettes.size)
    Box(
        modifier
            .clip(shape)
            .background(Brush.linearGradient(placeholderPalettes[seed])),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                painterResource(R.drawable.ic_note),
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.fillMaxSize(0.45f)
            )
        }
    }
}

@Composable
fun EqBars(playing: Boolean, modifier: Modifier = Modifier, color: Color = Pink) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(560, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val c by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(350, easing = LinearEasing), RepeatMode.Reverse), label = "c")
    Canvas(modifier.size(18.dp)) {
        val w = size.width / 5f
        val h = size.height
        val vals = if (playing) listOf(a, b, c) else listOf(0.3f, 0.3f, 0.3f)
        vals.forEachIndexed { i, v ->
            drawRoundRect(
                color = color,
                topLeft = Offset(i * 2 * w, h - h * v),
                size = Size(w, h * v),
                cornerRadius = CornerRadius(w / 2f)
            )
        }
    }
}
