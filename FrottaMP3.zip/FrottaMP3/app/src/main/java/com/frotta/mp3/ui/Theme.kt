package com.frotta.mp3.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0A0A10)
val Card = Color(0xFF15151E)
val CardHigh = Color(0xFF212130)
val Orange = Color(0xFFFF8A3D)
val Pink = Color(0xFFFF3D81)
val Violet = Color(0xFF8B5CF6)
val TextPrimary = Color(0xFFF5F5FA)
val TextSecondary = Color(0xFFA6A6BC)

val BrandBrush: Brush = Brush.linearGradient(listOf(Orange, Pink, Violet))

@Composable
fun FrottaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pink,
            secondary = Violet,
            background = Bg,
            surface = Card,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        ),
        content = content
    )
}
