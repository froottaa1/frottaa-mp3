package com.frotta.mp3.ui

import android.graphics.Bitmap
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.frotta.mp3.ArtLoader
import com.frotta.mp3.PlayerViewModel
import com.frotta.mp3.R

@Composable
fun NowPlayingScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    BackHandler(true) { onClose() }

    val song by vm.current.collectAsStateWithLifecycle()
    val playing by vm.isPlaying.collectAsStateWithLifecycle()
    val shuffle by vm.shuffle.collectAsStateWithLifecycle()
    val repeat by vm.repeat.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val s = song ?: return
    val context = LocalContext.current

    val accentInt by produceState<Int?>(null, s.id) { value = ArtLoader.accent(context, s) }
    val backdrop by produceState<Bitmap?>(null, s.id) { value = ArtLoader.load(context, s, 400) }
    val accent by animateColorAsState(accentInt?.let { Color(it) } ?: Pink, tween(600), label = "accent")
    val isFav = s.id in favs

    Box(
        Modifier.fillMaxSize()
            .background(Bg)
            .pointerInput(Unit) { detectTapGestures { } }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total > 200f) onClose() },
                    onVerticalDrag = { _, d -> total += d }
                )
            }
    ) {
        val b = backdrop
        if (b != null && Build.VERSION.SDK_INT >= 31) {
            Image(
                bitmap = b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(80.dp).graphicsLayer { alpha = 0.5f }
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        lerp(accent, Bg, 0.45f).copy(alpha = 0.85f),
                        lerp(accent, Bg, 0.8f).copy(alpha = 0.95f),
                        Bg
                    )
                )
            )
        )

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                CircleBtn(R.drawable.ic_down, onClose)
                Pill(stringResource(R.string.now_playing).uppercase(), size = 12.sp)
                CircleBtn(
                    if (isFav) R.drawable.ic_heart_filled else R.drawable.ic_heart,
                    { vm.toggleFavorite(s.id) },
                    tint = if (isFav) Pink else Color.White
                )
            }

            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 20.dp), contentAlignment = Alignment.Center) {
                val scale by animateFloatAsState(
                    if (playing) 1f else 0.88f,
                    spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow), label = "scale"
                )
                SongArt(
                    s,
                    Modifier.fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true)
                        .graphicsLayer { scaleX = scale; scaleY = scale }
                        .shadow(28.dp, RoundedCornerShape(32.dp), ambientColor = accent, spotColor = accent),
                    900,
                    RoundedCornerShape(32.dp)
                )
            }

            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Color.Black.copy(alpha = 0.4f))
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(s.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(s.artist, color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (s.album.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Pill(s.album, bg = Color.White.copy(alpha = 0.14f), color = Color.White.copy(alpha = 0.9f))
                }
            }

            Spacer(Modifier.height(12.dp))
            SeekSection(vm)
            Spacer(Modifier.height(8.dp))

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn(
                        R.drawable.ic_shuffle, { vm.toggleShuffle() },
                        bg = if (shuffle) Color.White.copy(alpha = 0.25f) else Color.Transparent,
                        tint = if (shuffle) Color.White else Color.White.copy(alpha = 0.6f)
                    )
                    CircleBtn(R.drawable.ic_prev, { vm.previous() }, size = 56.dp, iconSize = 30.dp, bg = Color.Transparent)
                    CircleBtn(
                        if (playing) R.drawable.ic_pause else R.drawable.ic_play,
                        { vm.togglePlay() }, size = 76.dp, iconSize = 38.dp, brush = BrandBrush
                    )
                    CircleBtn(R.drawable.ic_next, { vm.next() }, size = 56.dp, iconSize = 30.dp, bg = Color.Transparent)
                    CircleBtn(
                        if (repeat == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                        { vm.cycleRepeat() },
                        bg = if (repeat != Player.REPEAT_MODE_OFF) Color.White.copy(alpha = 0.25f) else Color.Transparent,
                        tint = if (repeat != Player.REPEAT_MODE_OFF) Color.White else Color.White.copy(alpha = 0.6f)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SeekSection(vm: PlayerViewModel) {
    val pos by vm.position.collectAsStateWithLifecycle()
    val dur by vm.duration.collectAsStateWithLifecycle()
    var drag by remember { mutableStateOf<Float?>(null) }
    val max = dur.coerceAtLeast(1L).toFloat()
    val value = (drag ?: pos.toFloat()).coerceIn(0f, max)

    Column {
        Slider(
            value = value,
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { vm.seekTo(it.toLong()) }
                drag = null
            },
            valueRange = 0f..max,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.White,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f)
            )
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Pill(formatTime(value.toLong()))
            Pill(formatTime(dur))
        }
    }
}
