package com.frotta.mp3

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ArtLoader {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val missing = java.util.Collections.synchronizedSet(HashSet<Long>())
    private val accents = LruCache<Long, Int>(300)

    suspend fun load(context: Context, song: Song, size: Int): Bitmap? = withContext(Dispatchers.IO) {
        val key = "${song.id}_$size"
        cache.get(key)?.let { return@withContext it }
        if (song.id in missing) return@withContext null
        val app = context.applicationContext
        var bmp: Bitmap? = try {
            if (Build.VERSION.SDK_INT >= 29)
                app.contentResolver.loadThumbnail(song.uri, Size(size, size), null)
            else legacy(app, song)
        } catch (e: Exception) {
            null
        }
        if (bmp == null) bmp = embedded(app, song.uri, size)
        if (bmp != null) cache.put(key, bmp) else missing.add(song.id)
        bmp
    }

    suspend fun accent(context: Context, song: Song): Int? = withContext(Dispatchers.IO) {
        accents.get(song.id)?.let { return@withContext it }
        val bmp = load(context, song, 200) ?: return@withContext null
        val soft = if (bmp.config == Bitmap.Config.HARDWARE) bmp.copy(Bitmap.Config.ARGB_8888, false) else bmp
        if (soft == null) return@withContext null
        val p = Palette.from(soft).maximumColorCount(12).generate()
        val sw = p.vibrantSwatch ?: p.dominantSwatch ?: p.mutedSwatch
        sw?.rgb?.also { accents.put(song.id, it) }
    }

    private fun legacy(ctx: Context, song: Song): Bitmap? {
        val art = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), song.albumId)
        return ctx.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
    }

    private fun embedded(ctx: Context, uri: Uri, size: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val bytes = r.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= size && bounds.outHeight / (sample * 2) >= size) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }
}
