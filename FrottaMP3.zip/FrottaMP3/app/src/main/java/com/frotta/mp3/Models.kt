package com.frotta.mp3

import android.content.ContentUris
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val uri: Uri
) {
    fun toMediaItem(): MediaItem {
        val art = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artist)
                    .setAlbumTitle(album)
                    .setArtworkUri(art)
                    .build()
            )
            .build()
    }
}

data class AlbumItem(val id: Long, val name: String, val artist: String, val songs: List<Song>)
data class ArtistItem(val name: String, val songs: List<Song>)
