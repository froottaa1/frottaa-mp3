package com.frotta.mp3.ui

import androidx.activity.compose.BackHandler
import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.frotta.mp3.AlbumItem
import com.frotta.mp3.ArtistItem
import com.frotta.mp3.PlayerViewModel
import com.frotta.mp3.R
import com.frotta.mp3.Song

private enum class LibTab(@StringRes val label: Int) {
    Songs(R.string.tab_songs),
    Albums(R.string.tab_albums),
    Artists(R.string.tab_artists),
    Liked(R.string.tab_liked)
}

private data class Detail(val title: String, val songs: List<Song>, val art: Song?, val circle: Boolean)

@Composable
fun LibraryScreen(vm: PlayerViewModel, onOpenPlayer: () -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()
    val playing by vm.isPlaying.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()

    var query by rememberSaveable { mutableStateOf("") }
    var tab by rememberSaveable { mutableStateOf(LibTab.Songs) }
    var detail by remember { mutableStateOf<Detail?>(null) }

    BackHandler(enabled = detail != null) { detail = null }

    val filtered = remember(songs, query) {
        if (query.isBlank()) songs else songs.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }
    val albums = remember(filtered) {
        filtered.groupBy { it.albumId }
            .map { (id, l) -> AlbumItem(id, l.first().album.ifBlank { l.first().title }, l.first().artist, l) }
            .sortedBy { it.name.lowercase() }
    }
    val artists = remember(filtered) {
        filtered.groupBy { it.artist }.map { (n, l) -> ArtistItem(n, l) }.sortedBy { it.name.lowercase() }
    }
    val liked = remember(filtered, favs) { filtered.filter { it.id in favs } }

    val bottomPad: Dp = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 120.dp
    val currentId = current?.id
    val play: (List<Song>, Int) -> Unit = { list, i ->
        if (list[i].id == currentId) onOpenPlayer() else vm.play(list, i)
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            AppHeader(songs.size)
            val d = detail
            if (d == null) {
                SearchField(query) { query = it }
                TabChips(tab) { tab = it }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Pink)
                    songs.isEmpty() -> EmptyState(R.string.empty_title, R.string.empty_body)
                    d != null -> SongList(d.songs, currentId, playing, bottomPad, play) {
                        DetailHeader(d.title, d.songs.size, d.art, d.circle) { detail = null }
                        ActionButtons({ vm.playInOrder(d.songs) }, { vm.playShuffled(d.songs) })
                    }
                    tab == LibTab.Liked && liked.isEmpty() -> EmptyState(R.string.tab_liked, R.string.empty_liked)
                    filtered.isEmpty() -> EmptyState(R.string.tab_songs, R.string.no_results)
                    else -> when (tab) {
                        LibTab.Songs -> SongList(filtered, currentId, playing, bottomPad, play) {
                            ActionButtons({ vm.playInOrder(filtered) }, { vm.playShuffled(filtered) })
                        }
                        LibTab.Liked -> SongList(liked, currentId, playing, bottomPad, play) {
                            ActionButtons({ vm.playInOrder(liked) }, { vm.playShuffled(liked) })
                        }
                        LibTab.Albums -> AlbumGrid(albums, bottomPad) {
                            detail = Detail(it.name, it.songs, it.songs.first(), false)
                        }
                        LibTab.Artists -> ArtistList(artists, bottomPad) {
                            detail = Detail(it.name, it.songs, it.songs.first(), true)
                        }
                    }
                }
            }
        }

        val cur = current
        AnimatedVisibility(
            visible = cur != null,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            if (cur != null) MiniPlayer(cur, vm, onOpenPlayer)
        }
    }
}

@Composable
private fun AppHeader(count: Int) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(BrandBrush),
            contentAlignment = Alignment.Center
        ) { Ic(R.drawable.ic_note, Color.White, 24.dp) }
        Spacer(Modifier.width(12.dp))
        Text("Frotta", style = TextStyle(brush = BrandBrush, fontSize = 28.sp, fontWeight = FontWeight.Black))
        Spacer(Modifier.width(8.dp))
        Pill("MP3", bg = CardHigh, color = TextPrimary, size = 12.sp)
        Spacer(Modifier.weight(1f))
        Pill(stringResource(R.string.n_songs, count), bg = CardHigh, color = TextSecondary, size = 12.sp)
    }
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp)).background(Card)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic(R.drawable.ic_search, TextSecondary, 20.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (query.isEmpty()) Text(stringResource(R.string.search_hint), color = TextSecondary, fontSize = 15.sp, maxLines = 1)
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = TextPrimary, fontSize = 15.sp),
                cursorBrush = SolidColor(Pink),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            Box(Modifier.clip(CircleShape).clickable { onChange("") }.padding(2.dp)) {
                Ic(R.drawable.ic_close, TextSecondary, 18.dp)
            }
        }
    }
}

@Composable
private fun TabChips(selected: LibTab, onSelect: (LibTab) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(LibTab.values().toList()) { t ->
            val on = t == selected
            Text(
                stringResource(t.label),
                color = if (on) Color.White else TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (on) BrandBrush else Brush.linearGradient(listOf(Card, Card)))
                    .clickable { onSelect(t) }
                    .padding(horizontal = 18.dp, vertical = 9.dp)
            )
        }
    }
}

@Composable
private fun ActionButtons(onPlay: () -> Unit, onShuffle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(BrandBrush)
                .clickable(onClick = onPlay).padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Ic(R.drawable.ic_play, Color.White, 22.dp)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.play), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Row(
            Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(CardHigh)
                .clickable(onClick = onShuffle).padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Ic(R.drawable.ic_shuffle, Color.White, 22.dp)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.shuffle), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DetailHeader(title: String, count: Int, art: Song?, circle: Boolean, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircleBtn(R.drawable.ic_back, onBack, bg = CardHigh)
        Spacer(Modifier.width(14.dp))
        SongArt(art, Modifier.size(72.dp), 300, if (circle) CircleShape else RoundedCornerShape(20.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Pill(stringResource(R.string.n_songs, count), bg = CardHigh, color = TextSecondary)
        }
    }
}

@Composable
private fun SongList(
    list: List<Song>,
    currentId: Long?,
    playing: Boolean,
    bottomPad: Dp,
    onPlay: (List<Song>, Int) -> Unit,
    header: @Composable () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = bottomPad)) {
        item { header() }
        itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
            SongRow(s, s.id == currentId, playing) { onPlay(list, i) }
        }
    }
}

@Composable
private fun SongRow(song: Song, isCurrent: Boolean, isPlaying: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(shape)
            .background(if (isCurrent) CardHigh else Card)
            .then(if (isCurrent) Modifier.border(1.dp, BrandBrush, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArt(song, Modifier.size(56.dp), 160, RoundedCornerShape(14.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = if (isCurrent) Pink else TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(song.artist, color = TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        if (isCurrent) EqBars(isPlaying) else Pill(formatTime(song.durationMs), bg = CardHigh, color = TextSecondary)
    }
}

@Composable
private fun AlbumGrid(albums: List<AlbumItem>, bottomPad: Dp, onClick: (AlbumItem) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = bottomPad),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(albums, key = { it.id }) { a ->
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { onClick(a) }
            ) {
                SongArt(a.songs.first(), Modifier.fillMaxSize(), 400, RoundedCornerShape(0.dp))
                Column(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(8.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.62f))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(a.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${a.artist} · ${a.songs.size}", color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun ArtistList(artists: List<ArtistItem>, bottomPad: Dp, onClick: (ArtistItem) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = bottomPad)) {
        items(artists, key = { it.name }) { a ->
            val shape = RoundedCornerShape(20.dp)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(shape).background(Card).clickable { onClick(a) }.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SongArt(a.songs.first(), Modifier.size(56.dp), 160, CircleShape)
                Spacer(Modifier.width(12.dp))
                Text(a.name, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Pill(stringResource(R.string.n_songs, a.songs.size), bg = CardHigh, color = TextSecondary)
            }
        }
    }
}

@Composable
fun EmptyState(@StringRes title: Int, @StringRes body: Int) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(84.dp).clip(CircleShape).background(CardHigh), contentAlignment = Alignment.Center) {
            Ic(R.drawable.ic_note, TextSecondary, 40.dp)
        }
        Spacer(Modifier.height(16.dp))
        Text(stringResource(title), color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(body), color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}
