package com.frotta.mp3

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.frotta.mp3.ui.FrottaApp
import com.frotta.mp3.ui.FrottaTheme

class MainActivity : ComponentActivity() {

    private val vm: PlayerViewModel by viewModels()
    private var hasPermission by mutableStateOf(false)

    private val launcher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refresh()
    }

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        hasPermission = granted()
        if (!hasPermission) requestPermissions()
        setContent {
            FrottaTheme {
                FrottaApp(vm, hasPermission, onRequest = { requestPermissions() })
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (granted()) {
            hasPermission = true
            vm.loadLibrary()
        }
    }

    private fun granted() =
        ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissions() {
        val list = mutableListOf(audioPermission)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        launcher.launch(list.toTypedArray())
    }

    private fun refresh() {
        if (granted() && !hasPermission) {
            hasPermission = true
            vm.loadLibrary()
        }
    }
}
