package com.frotta.mp3.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.frotta.mp3.PlayerViewModel
import com.frotta.mp3.R

@Composable
fun FrottaApp(vm: PlayerViewModel, hasPermission: Boolean, onRequest: () -> Unit) {
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    val current by vm.current.collectAsStateWithLifecycle()

    Surface(modifier = Modifier.fillMaxSize(), color = Bg, contentColor = TextPrimary) {
        Box(Modifier.fillMaxSize()) {
            if (!hasPermission) PermissionScreen(onRequest)
            else LibraryScreen(vm, onOpenPlayer = { showPlayer = true })

            AnimatedVisibility(
                visible = showPlayer && current != null,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) {
                NowPlayingScreen(vm, onClose = { showPlayer = false })
            }
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(110.dp).clip(RoundedCornerShape(34.dp)).background(BrandBrush),
            contentAlignment = Alignment.Center
        ) { Ic(R.drawable.ic_note, Color.White, 60.dp) }
        Spacer(Modifier.height(28.dp))
        Text(stringResource(R.string.perm_title), color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(R.string.perm_body), color = TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center,
            modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Card).padding(16.dp)
        )
        Spacer(Modifier.height(28.dp))
        Text(
            stringResource(R.string.perm_button), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(BrandBrush)
                .clickable(onClick = onRequest).padding(vertical = 16.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(R.string.perm_settings), color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(CardHigh)
                .clickable {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                    )
                }
                .padding(horizontal = 18.dp, vertical = 10.dp)
        )
    }
}
