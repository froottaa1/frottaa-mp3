package com.frotta.filemanager

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private fun p(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("frotta_fm", Context.MODE_PRIVATE)

    fun isGrid(ctx: Context) = p(ctx).getBoolean("grid", false)
    fun setGrid(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("grid", v).apply()

    fun sort(ctx: Context): FileOps.Sort =
        runCatching { FileOps.Sort.valueOf(p(ctx).getString("sort", "NAME") ?: "NAME") }
            .getOrDefault(FileOps.Sort.NAME)

    fun setSort(ctx: Context, s: FileOps.Sort) = p(ctx).edit().putString("sort", s.name).apply()

    fun showHidden(ctx: Context) = p(ctx).getBoolean("hidden", false)
    fun setShowHidden(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("hidden", v).apply()

    fun useTrash(ctx: Context) = p(ctx).getBoolean("use_trash", true)
    fun setUseTrash(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("use_trash", v).apply()

    fun favorites(ctx: Context): List<String> =
        LinkedHashSet(p(ctx).getStringSet("fav", emptySet()) ?: emptySet()).toList()

    fun isFavorite(ctx: Context, path: String) = path in favorites(ctx)

    /** Returns true if the path is now a favorite. */
    fun toggleFavorite(ctx: Context, path: String): Boolean {
        val set = LinkedHashSet(favorites(ctx))
        val now = set.add(path)
        if (!now) set.remove(path)
        p(ctx).edit().putStringSet("fav", set).apply()
        return now
    }
}
