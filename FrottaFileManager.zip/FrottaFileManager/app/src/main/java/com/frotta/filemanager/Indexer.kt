package com.frotta.filemanager

import android.content.Context
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes
import java.util.concurrent.atomic.AtomicBoolean

enum class Category(
    @StringRes val title: Int,
    @DrawableRes val icon: Int,
    @ColorRes val color: Int,
    val kind: FileOps.Kind?
) {
    IMAGES(R.string.cat_images, R.drawable.ic_image, R.color.c_image, FileOps.Kind.IMAGE),
    VIDEOS(R.string.cat_videos, R.drawable.ic_video, R.color.c_video, FileOps.Kind.VIDEO),
    AUDIO(R.string.cat_audio, R.drawable.ic_audio, R.color.c_audio, FileOps.Kind.AUDIO),
    DOCS(R.string.cat_docs, R.drawable.ic_doc, R.color.c_doc, FileOps.Kind.DOC),
    DOWNLOADS(R.string.cat_downloads, R.drawable.ic_download, R.color.orange, null),
    APKS(R.string.cat_apks, R.drawable.ic_apk, R.color.c_apk, FileOps.Kind.APK),
    ARCHIVES(R.string.cat_archives, R.drawable.ic_archive, R.color.c_archive, FileOps.Kind.ARCHIVE)
}

data class Meta(val path: String, val size: Long, val modified: Long, val kind: FileOps.Kind)

/** In-memory index of all files, built once with a fast tree walk. */
object Indexer {

    @Volatile
    var all: List<Meta> = emptyList()
        private set

    @Volatile
    var ready = false
        private set

    @Volatile
    var dirty = false
        private set

    private val scanning = AtomicBoolean(false)
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile
    private var stats: Map<Category, Pair<Int, Long>> = emptyMap()

    val version = MutableStateFlow(0)

    private fun downloadsPrefix() = Storage.internalRoot().path + "/Download/"

    fun stat(c: Category): Pair<Int, Long> = stats[c] ?: (0 to 0L)

    fun markDirty() {
        dirty = true
    }

    fun remove(paths: Collection<String>) {
        if (paths.isEmpty()) return
        val set = paths.toHashSet()
        all = all.filter { m -> m.path !in set && set.none { m.path.startsWith("$it/") } }
        computeStats()
        version.value = version.value + 1
    }

    fun ensure(ctx: Context) {
        if (scanning.get()) return
        if (ready && !dirty) return
        val roots = Storage.volumes(ctx).map { it.root }
        appScope.launch { scan(roots) }
    }

    fun rescan(ctx: Context) {
        dirty = true
        ensure(ctx)
    }

    private fun scan(roots: List<File>) {
        if (!scanning.compareAndSet(false, true)) return
        try {
            val out = ArrayList<Meta>(50000)
            for (root in roots) {
                val rootPath = root.toPath()
                Files.walkFileTree(rootPath, object : SimpleFileVisitor<Path>() {
                    override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                        val name = dir.fileName?.toString() ?: ""
                        if (dir != rootPath && name.startsWith(".")) return FileVisitResult.SKIP_SUBTREE
                        if (dir.parent == rootPath && name == "Android") return FileVisitResult.SKIP_SUBTREE
                        return FileVisitResult.CONTINUE
                    }

                    override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                        val name = file.fileName.toString()
                        if (!name.startsWith(".")) {
                            val ext = name.substringAfterLast('.', "").lowercase()
                            out.add(
                                Meta(
                                    file.toString(),
                                    attrs.size(),
                                    attrs.lastModifiedTime().toMillis(),
                                    FileOps.kindOfExt(ext)
                                )
                            )
                        }
                        return FileVisitResult.CONTINUE
                    }

                    override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult =
                        FileVisitResult.CONTINUE
                })
            }
            all = out
            ready = true
            dirty = false
            computeStats()
            version.value = version.value + 1
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            scanning.set(false)
        }
    }

    private fun matches(m: Meta, c: Category, dl: String): Boolean =
        if (c.kind != null) m.kind == c.kind else m.path.startsWith(dl)

    private fun computeStats() {
        val dl = downloadsPrefix()
        val map = HashMap<Category, Pair<Int, Long>>()
        for (c in Category.values()) {
            var n = 0
            var s = 0L
            for (m in all) {
                if (matches(m, c, dl)) {
                    n++
                    s += m.size
                }
            }
            map[c] = n to s
        }
        stats = map
    }

    private fun toItem(m: Meta): FileItem =
        FileItem(File(m.path), false, m.path.substringAfterLast('/'), m.size, m.modified, 0)

    fun itemsFor(c: Category): List<FileItem> {
        val dl = downloadsPrefix()
        return all.filter { matches(it, c, dl) }.map { toItem(it) }
    }

    fun recent(): List<FileItem> =
        all.asSequence()
            .filter { it.kind != FileOps.Kind.OTHER }
            .sortedByDescending { it.modified }
            .take(150)
            .map { toItem(it) }
            .toList()

    fun large(): List<FileItem> =
        all.asSequence()
            .filter { it.size >= 20L * 1024 * 1024 }
            .sortedByDescending { it.size }
            .take(100)
            .map { toItem(it) }
            .toList()

    fun search(query: String, limit: Int = 300): List<FileItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return all.asSequence()
            .filter { it.path.substringAfterLast('/').lowercase().contains(q) }
            .take(limit)
            .map { toItem(it) }
            .toList()
    }
}
