package com.frotta.filemanager

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.LruCache
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** Loads small previews for images, videos, APK icons and audio covers. */
object ThumbLoader {

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 10).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val sem = Semaphore(3)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    fun supports(kind: FileOps.Kind): Boolean =
        kind == FileOps.Kind.IMAGE || kind == FileOps.Kind.VIDEO ||
            kind == FileOps.Kind.APK || kind == FileOps.Kind.AUDIO

    fun load(
        ctx: Context,
        path: String,
        modified: Long,
        kind: FileOps.Kind,
        px: Int,
        onDone: (Bitmap?) -> Unit
    ): Job {
        val app = ctx.applicationContext
        val key = "$path|$modified|$px"
        return scope.launch {
            val hit = cache.get(key)
            if (hit != null) {
                onDone(hit)
            } else {
                val bmp = sem.withPermit { withContext(Dispatchers.IO) { decode(app, path, kind, px) } }
                if (bmp != null) cache.put(key, bmp)
                onDone(bmp)
            }
        }
    }

    fun loadAppIcon(ctx: Context, pkg: String, px: Int, onDone: (Bitmap?) -> Unit): Job {
        val app = ctx.applicationContext
        val key = "pkg:$pkg|$px"
        return scope.launch {
            val hit = cache.get(key)
            if (hit != null) {
                onDone(hit)
            } else {
                val bmp = sem.withPermit {
                    withContext(Dispatchers.IO) {
                        runCatching { app.packageManager.getApplicationIcon(pkg).toBitmap(px, px) }.getOrNull()
                    }
                }
                if (bmp != null) cache.put(key, bmp)
                onDone(bmp)
            }
        }
    }

    private fun decode(ctx: Context, path: String, kind: FileOps.Kind, px: Int): Bitmap? = try {
        when (kind) {
            FileOps.Kind.IMAGE -> decodeImage(path, px)
            FileOps.Kind.VIDEO -> decodeVideo(path)
            FileOps.Kind.AUDIO -> decodeAudio(path, px)
            FileOps.Kind.APK -> decodeApk(ctx, path, px)
            else -> null
        }
    } catch (e: Throwable) {
        null
    }

    private fun sample(w: Int, h: Int, px: Int): Int {
        var s = 1
        while (w / (s * 2) >= px && h / (s * 2) >= px) s *= 2
        return s
    }

    private fun decodeImage(path: String, px: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val opts = BitmapFactory.Options().apply { inSampleSize = sample(bounds.outWidth, bounds.outHeight, px) }
        return BitmapFactory.decodeFile(path, opts)
    }

    private fun decodeVideo(path: String): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun decodeAudio(path: String, px: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            val bytes = r.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            val opts = BitmapFactory.Options().apply { inSampleSize = sample(bounds.outWidth, bounds.outHeight, px) }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun decodeApk(ctx: Context, path: String, px: Int): Bitmap? {
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(path, 0) ?: return null
        val ai = info.applicationInfo ?: return null
        ai.sourceDir = path
        ai.publicSourceDir = path
        return ai.loadIcon(pm).toBitmap(px, px)
    }
}
