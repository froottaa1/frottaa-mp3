package com.frotta.filemanager

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.frotta.filemanager.databinding.ActivityAppsBinding
import com.frotta.filemanager.databinding.ItemAppBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class AppItem(
    val label: String,
    val pkg: String,
    val version: String,
    val apk: String,
    val size: Long,
    val system: Boolean
)

class AppAdapter(private val onClick: (AppItem) -> Unit) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(val b: ItemAppBinding) : RecyclerView.ViewHolder(b.root) {
        var job: Job? = null
        var pkg: String? = null
    }

    private var items: List<AppItem> = emptyList()

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        super.onViewRecycled(holder)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val a = items[position]
        holder.job?.cancel()
        holder.pkg = a.pkg
        holder.b.appName.text = a.label
        holder.b.appMeta.text = a.pkg + " · " + a.version + " · " + FileOps.formatSize(a.size)
        holder.b.appIcon.setImageDrawable(null)
        holder.job = ThumbLoader.loadAppIcon(holder.b.root.context, a.pkg, 96) { bmp: Bitmap? ->
            if (bmp != null && holder.pkg == a.pkg) holder.b.appIcon.setImageBitmap(bmp)
        }
        holder.b.root.setOnClickListener { onClick(a) }
    }
}

class AppsActivity : AppCompatActivity() {

    private lateinit var b: ActivityAppsBinding
    private val adapter = AppAdapter { showOptions(it) }
    private var all: List<AppItem> = emptyList()
    private var query = ""
    private var showSystem = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAppsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.toolbar.setTitle(R.string.tool_apps)
        b.toolbar.setNavigationIcon(R.drawable.ic_up)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.inflateMenu(R.menu.apps_menu)
        b.toolbar.setOnMenuItemClickListener { onMenu(it) }
        setupSearch(b.toolbar.menu.findItem(R.id.action_search))

        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        load()
    }

    private fun setupSearch(item: MenuItem) {
        val sv = item.actionView as SearchView
        sv.maxWidth = Int.MAX_VALUE
        sv.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)?.apply {
            setTextColor(ContextCompat.getColor(this@AppsActivity, R.color.text_primary))
            setHintTextColor(ContextCompat.getColor(this@AppsActivity, R.color.text_secondary))
        }
        sv.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(q: String?): Boolean = true
            override fun onQueryTextChange(newText: String?): Boolean {
                query = newText.orEmpty()
                applyFilter()
                return true
            }
        })
    }

    private fun onMenu(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_system) {
            showSystem = !showSystem
            item.isChecked = showSystem
            applyFilter()
            return true
        }
        return false
    }

    private fun load() {
        b.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            all = withContext(Dispatchers.IO) { loadApps() }
            b.progress.visibility = View.INVISIBLE
            applyFilter()
        }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        return pm.getInstalledApplications(0).map { ai ->
            val src = ai.sourceDir ?: ""
            AppItem(
                label = ai.loadLabel(pm).toString(),
                pkg = ai.packageName,
                version = runCatching { pm.getPackageInfo(ai.packageName, 0).versionName }.getOrNull() ?: "",
                apk = src,
                size = if (src.isEmpty()) 0L else File(src).length(),
                system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        }.sortedBy { it.label.lowercase() }
    }

    private fun applyFilter() {
        val q = query.trim()
        adapter.submit(
            all.filter { (showSystem || !it.system) && (q.isEmpty() || it.label.contains(q, true) || it.pkg.contains(q, true)) }
        )
    }

    private fun showOptions(app: AppItem) {
        val labels = mutableListOf(getString(R.string.backup_apk), getString(R.string.app_info))
        if (!app.system) labels.add(getString(R.string.uninstall))
        MaterialAlertDialogBuilder(this)
            .setTitle(app.label)
            .setItems(labels.toTypedArray()) { _, which ->
                when (which) {
                    0 -> backup(app)
                    1 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                    )
                    else -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
                }
            }
            .show()
    }

    private fun backup(app: AppItem) {
        lifecycleScope.launch {
            val out = withContext(Dispatchers.IO) {
                runCatching {
                    val dir = File(Storage.internalRoot(), "Frotta/Backups")
                    dir.mkdirs()
                    val target = FileOps.uniqueTarget(dir, "${app.pkg}_${app.version}.apk", false)
                    File(app.apk).copyTo(target)
                    target
                }.getOrNull()
            }
            Indexer.markDirty()
            val msg = if (out != null) getString(R.string.backup_done, out.path) else getString(R.string.backup_failed)
            Toast.makeText(this@AppsActivity, msg, Toast.LENGTH_LONG).show()
        }
    }
}
