package com.frotta.filemanager

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class TrashEntry(
    val id: String,
    val name: String,
    val originalPath: String,
    val deletedAt: Long,
    val isDir: Boolean
)

/** Simple recycle bin stored in a hidden folder on internal storage. */
object TrashManager {

    private val lock = Any()

    private fun trashDir(): File = File(Storage.internalRoot(), ".FrottaTrash").also { it.mkdirs() }
    private fun indexFile(): File = File(trashDir(), ".index.json")

    fun fileFor(e: TrashEntry): File = File(trashDir(), e.id)

    private fun read(): MutableList<TrashEntry> {
        val f = indexFile()
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            val list = mutableListOf<TrashEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    TrashEntry(
                        o.getString("id"), o.getString("name"), o.getString("path"),
                        o.getLong("at"), o.getBoolean("dir")
                    )
                )
            }
            list
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun write(list: List<TrashEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("path", it.originalPath)
                    .put("at", it.deletedAt).put("dir", it.isDir)
            )
        }
        indexFile().writeText(arr.toString())
    }

    fun entries(): List<TrashEntry> = synchronized(lock) { read().sortedByDescending { it.deletedAt } }

    fun trash(f: File): Boolean = synchronized(lock) {
        try {
            val isDir = f.isDirectory
            val id = System.currentTimeMillis().toString() + "_" + (f.name.hashCode() and 0xffff)
            val moved = FileOps.moveTo(f, File(trashDir(), id))
            if (moved) {
                val list = read()
                list.add(TrashEntry(id, f.name, f.path, System.currentTimeMillis(), isDir))
                write(list)
            }
            moved
        } catch (e: Exception) {
            false
        }
    }

    fun restore(e: TrashEntry): Boolean = synchronized(lock) {
        try {
            val src = fileFor(e)
            val list = read()
            val ok = if (!src.exists()) {
                true
            } else {
                val orig = File(e.originalPath)
                val parent = orig.parentFile
                if (parent == null) {
                    false
                } else {
                    parent.mkdirs()
                    val target = if (orig.exists()) FileOps.uniqueTarget(parent, orig.name, e.isDir) else orig
                    FileOps.moveTo(src, target)
                }
            }
            if (ok) {
                list.removeAll { it.id == e.id }
                write(list)
            }
            ok
        } catch (ex: Exception) {
            false
        }
    }

    fun deleteForever(e: TrashEntry): Boolean = synchronized(lock) {
        try {
            fileFor(e).deleteRecursively()
            val list = read()
            list.removeAll { it.id == e.id }
            write(list)
            true
        } catch (ex: Exception) {
            false
        }
    }

    fun empty() {
        entries().forEach { deleteForever(it) }
    }

    fun purgeOld(days: Int) {
        val limit = System.currentTimeMillis() - days * 24L * 60 * 60 * 1000
        entries().filter { it.deletedAt < limit }.forEach { deleteForever(it) }
    }
}
