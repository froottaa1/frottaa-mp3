package com.frotta.filemanager

import android.os.Bundle
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.frotta.filemanager.databinding.ActivityTextEditorBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class TextEditorActivity : AppCompatActivity() {

    private lateinit var b: ActivityTextEditorBinding
    private lateinit var file: File
    private var loaded = false
    private var modified = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("path")
        if (path == null) {
            finish()
            return
        }
        file = File(path)
        b = ActivityTextEditorBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.toolbar.title = file.name
        b.toolbar.setNavigationIcon(R.drawable.ic_up)
        b.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
        b.toolbar.inflateMenu(R.menu.editor_menu)
        b.toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.action_save) {
                save(false)
                true
            } else false
        }

        b.editor.doAfterTextChanged { if (loaded) modified = true }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!modified) {
                    finish()
                    return
                }
                MaterialAlertDialogBuilder(this@TextEditorActivity)
                    .setTitle(R.string.unsaved_title)
                    .setMessage(R.string.unsaved_message)
                    .setPositiveButton(R.string.save) { _, _ -> save(true) }
                    .setNegativeButton(R.string.discard) { _, _ -> finish() }
                    .setNeutralButton(R.string.cancel, null)
                    .show()
            }
        })

        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                if (file.length() > 2L * 1024 * 1024) null
                else runCatching { file.readText() }.getOrNull()
            }
            if (text == null) {
                Toast.makeText(this@TextEditorActivity, R.string.too_large, Toast.LENGTH_SHORT).show()
                finish()
            } else {
                b.editor.setText(text)
                loaded = true
                modified = false
            }
        }
    }

    private fun save(thenFinish: Boolean) {
        val text = b.editor.text.toString()
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { file.writeText(text) }.isSuccess }
            if (ok) {
                modified = false
                Indexer.markDirty()
                Toast.makeText(this@TextEditorActivity, R.string.saved, Toast.LENGTH_SHORT).show()
                if (thenFinish) finish()
            } else {
                Toast.makeText(this@TextEditorActivity, R.string.name_invalid, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
