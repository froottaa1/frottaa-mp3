package com.frotta.filemanager

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.frotta.filemanager.databinding.ActivityFilesBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class FilesActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_START = "start"
        const val EXTRA_CATEGORY = "category"
        const val MODE_DIR = "dir"
        const val MODE_CATEGORY = "category"
        const val MODE_RECENT = "recent"
        const val MODE_LARGE = "large"
        const val MODE_SEARCH = "search"

        fun dir(ctx: Context, path: String): Intent =
            Intent(ctx, FilesActivity::class.java).putExtra(EXTRA_MODE, MODE_DIR).putExtra(EXTRA_START, path)

        fun category(ctx: Context, c: Category): Intent =
            Intent(ctx, FilesActivity::class.java).putExtra(EXTRA_MODE, MODE_CATEGORY).putExtra(EXTRA_CATEGORY, c.name)

        fun simple(ctx: Context, mode: String): Intent =
            Intent(ctx, FilesActivity::class.java).putExtra(EXTRA_MODE, mode)
    }

    private lateinit var b: ActivityFilesBinding
    private lateinit var adapter: FileAdapter
    private lateinit var mode: String
    private lateinit var rootDir: File
    private lateinit var currentDir: File
    private var category: Category? = null
    private var showHidden = false
    private var sort = FileOps.Sort.NAME
    private var grid = false
    private var searching = false
    private var searchOpened = false
    private var baseItems: List<FileItem> = emptyList()
    private var loadJob: Job? = null
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Storage.hasAccess(this)) {
            finish()
            return
        }
        b = ActivityFilesBinding.inflate(layoutInflater)
        setContentView(b.root)

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_DIR
        val start = intent.getStringExtra(EXTRA_START)?.let { File(it) } ?: Storage.internalRoot()
        rootDir = Storage.rootFor(this, start.path)
        currentDir = if (start.isDirectory) start else rootDir
        category = intent.getStringExtra(EXTRA_CATEGORY)?.let { runCatching { Category.valueOf(it) }.getOrNull() }
        showHidden = Prefs.showHidden(this)
        sort = Prefs.sort(this)
        grid = Prefs.isGrid(this)

        adapter = FileAdapter(onClick = ::onItemClick, onLongClick = ::onItemLong)
        b.recycler.adapter = adapter
        applyLayout()

        b.pasteButton.setOnClickListener { paste() }
        b.cancelPasteButton.setOnClickListener {
            Clipboard.files = emptyList()
            updatePasteBar()
        }
        b.pathText.setOnClickListener { if (mode == MODE_DIR && !searching) goUp() }

        b.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
        b.toolbar.setOnMenuItemClickListener { onMenu(it) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    adapter.selectedCount() > 0 -> clearSelection()
                    searching -> collapseSearch()
                    mode == MODE_DIR && currentDir != rootDir -> goUp()
                    else -> finish()
                }
            }
        })

        lifecycleScope.launch {
            Indexer.version.drop(1).collect {
                if ((mode == MODE_CATEGORY || mode == MODE_RECENT || mode == MODE_LARGE) &&
                    !searching && adapter.selectedCount() == 0
                ) {
                    load(false)
                }
            }
        }

        updatePasteBar()
        load()
    }

    // ------------------------------------------------------------ layout

    private fun applyLayout() {
        val dm = resources.displayMetrics
        val span = (dm.widthPixels / dm.density / 110f).toInt().coerceAtLeast(3)
        b.recycler.layoutManager = if (grid) GridLayoutManager(this, span) else LinearLayoutManager(this)
        adapter.setGrid(grid)
    }

    private fun busy(on: Boolean) {
        b.progress.visibility = if (on) View.VISIBLE else View.INVISIBLE
    }

    private fun titleFor(): String = when (mode) {
        MODE_DIR -> if (currentDir == rootDir) {
            Storage.volumes(this).firstOrNull { it.root == rootDir }?.name ?: getString(R.string.storage)
        } else currentDir.name
        MODE_CATEGORY -> category?.let { getString(it.title) } ?: ""
        MODE_RECENT -> getString(R.string.tool_recent)
        MODE_LARGE -> getString(R.string.tool_large)
        else -> getString(R.string.search)
    }

    private fun pathLabel(): String {
        if (mode == MODE_DIR) {
            val storage = Storage.volumes(this).firstOrNull { it.root == rootDir }?.name ?: getString(R.string.storage)
            val rel = runCatching { currentDir.relativeTo(rootDir).path }.getOrDefault(currentDir.path)
            return if (rel.isEmpty()) storage else storage + " › " + rel.replace(File.separator, " › ")
        }
        return titleFor() + " · " + baseItems.size
    }

    // ------------------------------------------------------------ loading

    private fun load(updateBar: Boolean = true) {
        loadJob?.cancel()
        searchJob?.cancel()
        busy(true)
        val m = mode
        val dir = currentDir
        val sortNow = sort
        val hidden = showHidden
        val cat = category
        loadJob = lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) {
                when (m) {
                    MODE_DIR -> FileOps.list(dir, hidden, sortNow)
                    MODE_CATEGORY -> cat?.let { FileOps.sortItems(Indexer.itemsFor(it), sortNow) } ?: emptyList()
                    MODE_RECENT -> Indexer.recent()
                    MODE_LARGE -> Indexer.large()
                    else -> emptyList()
                }
            }
            baseItems = list
            showItems(list, false)
            busy(false)
            if (updateBar) updateToolbar()
        }
    }

    private fun showItems(list: List<FileItem>, results: Boolean) {
        adapter.submit(list, results || mode != MODE_DIR)
        b.emptyText.setText(
            if (!Indexer.ready && mode != MODE_DIR) R.string.scanning
            else if (results) R.string.no_results else R.string.empty_folder
        )
        b.emptyText.visibility = if (list.isEmpty() && !(mode == MODE_SEARCH && !searching)) View.VISIBLE else View.GONE
        b.pathText.text = if (results) getString(R.string.search_results, list.size) else pathLabel()
    }

    private fun goUp() {
        if (currentDir == rootDir) return
        currentDir = currentDir.parentFile ?: rootDir
        load()
    }

    // ------------------------------------------------------------ toolbar

    private fun updateToolbar() {
        val tb = b.toolbar
        tb.menu.clear()
        val sel = adapter.selectedCount()
        if (sel > 0) {
            tb.inflateMenu(R.menu.selection_menu)
            tb.title = getString(R.string.selected_count, sel)
            tb.setNavigationIcon(R.drawable.ic_close)
            val files = adapter.selectedFiles()
            tb.menu.findItem(R.id.action_rename).isVisible = sel == 1
            tb.menu.findItem(R.id.action_share).isVisible = files.none { it.isDirectory }
            tb.menu.findItem(R.id.action_extract).isVisible = sel == 1 && files.isNotEmpty() && FileOps.isZip(files[0])
            tb.menu.findItem(R.id.action_open_location).isVisible = mode != MODE_DIR && sel == 1
        } else {
            tb.inflateMenu(R.menu.files_menu)
            tb.title = titleFor()
            tb.setNavigationIcon(R.drawable.ic_up)
            val isDir = mode == MODE_DIR
            val m = tb.menu
            m.findItem(R.id.action_new_folder).isVisible = isDir
            m.findItem(R.id.action_new_file).isVisible = isDir
            m.findItem(R.id.action_hidden).isVisible = isDir
            m.findItem(R.id.action_hidden).isChecked = showHidden
            m.findItem(R.id.action_sort).isVisible = isDir || mode == MODE_CATEGORY
            val fav = m.findItem(R.id.action_favorite)
            fav.isVisible = isDir && currentDir != rootDir
            fav.setIcon(
                if (Prefs.isFavorite(this, currentDir.path)) R.drawable.ic_star else R.drawable.ic_star_outline
            )
            val view = m.findItem(R.id.action_view)
            view.setIcon(if (grid) R.drawable.ic_list else R.drawable.ic_grid)
            view.setTitle(if (grid) R.string.view_list else R.string.view_grid)
            val sortId = when (sort) {
                FileOps.Sort.NAME -> R.id.sort_name
                FileOps.Sort.DATE -> R.id.sort_date
                FileOps.Sort.SIZE -> R.id.sort_size
            }
            m.findItem(sortId).isChecked = true
            val searchItem = m.findItem(R.id.action_search)
            setupSearch(searchItem)
            if (mode == MODE_SEARCH && !searchOpened) {
                searchOpened = true
                searchItem.expandActionView()
            }
        }
    }

    private fun setupSearch(item: MenuItem) {
        val sv = item.actionView as SearchView
        sv.queryHint = getString(if (mode == MODE_SEARCH) R.string.search_all_hint else R.string.search_hint)
        sv.maxWidth = Int.MAX_VALUE
        sv.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)?.apply {
            setTextColor(ContextCompat.getColor(this@FilesActivity, R.color.text_primary))
            setHintTextColor(ContextCompat.getColor(this@FilesActivity, R.color.text_secondary))
        }
        sv.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                runSearch(query.orEmpty())
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (searching) runSearch(newText.orEmpty())
                return true
            }
        })
        item.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
            override fun onMenuItemActionExpand(item: MenuItem): Boolean {
                searching = true
                return true
            }

            override fun onMenuItemActionCollapse(item: MenuItem): Boolean {
                searching = false
                searchJob?.cancel()
                if (mode == MODE_SEARCH) finish() else load()
                return true
            }
        })
    }

    private fun collapseSearch() {
        val item = b.toolbar.menu.findItem(R.id.action_search)
        if (item != null && item.isActionViewExpanded) {
            item.collapseActionView()
        } else {
            searching = false
            load()
        }
    }

    private fun runSearch(query: String) {
        searchJob?.cancel()
        loadJob?.cancel()
        if (query.isBlank()) {
            if (mode == MODE_DIR) load(false) else {
                busy(false)
                showItems(if (mode == MODE_SEARCH) emptyList() else baseItems, false)
            }
            return
        }
        val m = mode
        val base = currentDir
        val hidden = showHidden
        val local = baseItems
        busy(true)
        searchJob = lifecycleScope.launch {
            delay(250)
            val res = when (m) {
                MODE_DIR -> FileOps.search(base, query, hidden)
                MODE_SEARCH -> withContext(Dispatchers.Default) { Indexer.search(query) }
                else -> withContext(Dispatchers.Default) {
                    local.filter { it.name.contains(query.trim(), ignoreCase = true) }
                }
            }
            showItems(res, true)
            busy(false)
        }
    }

    private fun onMenu(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_new_folder -> promptName(R.string.new_folder, "") { name ->
                toast(if (FileOps.mkdir(currentDir, name)) R.string.created else R.string.name_invalid)
                load()
            }
            R.id.action_new_file -> promptName(R.string.new_file, "") { name ->
                toast(if (FileOps.newFile(currentDir, name)) R.string.created else R.string.name_invalid)
                Indexer.markDirty()
                load()
            }
            R.id.sort_name -> setSort(FileOps.Sort.NAME)
            R.id.sort_date -> setSort(FileOps.Sort.DATE)
            R.id.sort_size -> setSort(FileOps.Sort.SIZE)
            R.id.action_hidden -> {
                showHidden = !showHidden
                Prefs.setShowHidden(this, showHidden)
                load()
            }
            R.id.action_refresh -> {
                Indexer.markDirty()
                Indexer.ensure(this)
                load()
            }
            R.id.action_favorite -> {
                val now = Prefs.toggleFavorite(this, currentDir.path)
                toast(if (now) R.string.fav_added else R.string.fav_removed)
                updateToolbar()
            }
            R.id.action_view -> {
                grid = !grid
                Prefs.setGrid(this, grid)
                applyLayout()
                updateToolbar()
            }
            R.id.action_copy -> setClipboard(move = false)
            R.id.action_cut -> setClipboard(move = true)
            R.id.action_delete -> confirmDelete()
            R.id.action_share -> FileOps.share(this, adapter.selectedFiles())
            R.id.action_rename -> promptRename()
            R.id.action_properties -> showProperties(adapter.selectedFiles())
            R.id.action_compress -> compress()
            R.id.action_extract -> adapter.selectedFiles().firstOrNull()?.let { extractHere(it) }
            R.id.action_open_location -> adapter.selectedFiles().firstOrNull()?.let { openLocation(it) }
            R.id.action_select_all -> {
                adapter.selectAll()
                updateToolbar()
            }
            else -> return false
        }
        return true
    }

    private fun setSort(s: FileOps.Sort) {
        sort = s
        Prefs.setSort(this, s)
        load()
    }

    // ------------------------------------------------------------ item events

    private fun onItemClick(item: FileItem) {
        if (adapter.selectedCount() > 0) {
            adapter.toggle(item)
            updateToolbar()
            return
        }
        if (item.isDir) {
            currentDir = item.file
            if (searching) collapseSearch() else load()
            return
        }
        val f = item.file
        when {
            FileOps.isZip(f) -> MaterialAlertDialogBuilder(this)
                .setTitle(f.name)
                .setItems(arrayOf(getString(R.string.extract), getString(R.string.open_with))) { _, which ->
                    if (which == 0) extractHere(f) else FileOps.open(this, f)
                }
                .show()
            FileOps.isText(f) -> startActivity(
                Intent(this, TextEditorActivity::class.java).putExtra("path", f.path)
            )
            else -> FileOps.open(this, f)
        }
    }

    private fun onItemLong(item: FileItem) {
        if (searching) {
            quickMenu(item)
            return
        }
        adapter.toggle(item)
        updateToolbar()
    }

    private fun quickMenu(item: FileItem) {
        val labels = arrayOf(R.string.open_location, R.string.share, R.string.properties)
            .map { getString(it) }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(item.name)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> openLocation(item.file)
                    1 -> FileOps.share(this, listOf(item.file))
                    else -> showProperties(listOf(item.file))
                }
            }
            .show()
    }

    private fun openLocation(file: File) {
        val p = file.parentFile ?: return
        startActivity(dir(this, p.path))
    }

    private fun clearSelection() {
        adapter.clearSelection()
        updateToolbar()
    }

    // ------------------------------------------------------------ actions

    private fun setClipboard(move: Boolean) {
        Clipboard.files = adapter.selectedFiles()
        Clipboard.move = move
        adapter.clearSelection()
        updateToolbar()
        updatePasteBar()
    }

    private fun updatePasteBar() {
        val files = Clipboard.files
        b.pasteBar.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE
        b.pasteButton.visibility = if (mode == MODE_DIR) View.VISIBLE else View.GONE
        b.pasteInfo.text = getString(if (Clipboard.move) R.string.clip_move else R.string.clip_copy, files.size)
    }

    private fun paste() {
        val files = Clipboard.files
        if (files.isEmpty() || mode != MODE_DIR) return
        val move = Clipboard.move
        val dest = currentDir
        busy(true)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                files.count { if (move) FileOps.move(it, dest) else FileOps.copy(it, dest) }
            }
            if (move) Indexer.remove(files.map { it.path })
            Indexer.markDirty()
            Clipboard.files = emptyList()
            updatePasteBar()
            toast(getString(R.string.done_result, ok, files.size - ok))
            load()
        }
    }

    private fun confirmDelete() {
        val files = adapter.selectedFiles()
        if (files.isEmpty()) return
        val trash = Prefs.useTrash(this)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.delete)
            .setMessage(getString(if (trash) R.string.trash_message else R.string.delete_message, files.size))
            .setPositiveButton(R.string.delete) { _, _ -> doDelete(files, trash) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun doDelete(files: List<File>, trash: Boolean) {
        busy(true)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                files.count { if (trash) TrashManager.trash(it) else FileOps.delete(it) }
            }
            Indexer.remove(files.map { it.path })
            toast(getString(R.string.done_result, ok, files.size - ok))
            load()
        }
    }

    private fun promptRename() {
        val file = adapter.selectedFiles().firstOrNull() ?: return
        promptName(R.string.rename, file.name) { name ->
            val ok = FileOps.rename(file, name)
            if (ok) {
                Indexer.remove(listOf(file.path))
                Indexer.markDirty()
            }
            toast(if (ok) R.string.renamed else R.string.name_invalid)
            load()
        }
    }

    private fun compress() {
        val files = adapter.selectedFiles()
        if (files.isEmpty()) return
        val defaultName = if (files.size == 1) files[0].nameWithoutExtension else getString(R.string.archive_name)
        promptName(R.string.compress, defaultName) { name ->
            val destDir = files[0].parentFile ?: currentDir
            val n = name.trim().removeSuffix(".zip")
            if (n.isBlank() || n.contains('/')) {
                toast(R.string.name_invalid)
                return@promptName
            }
            val out = FileOps.uniqueTarget(destDir, "$n.zip", false)
            busy(true)
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) { FileOps.zip(files, out) }
                Indexer.markDirty()
                toast(if (ok) R.string.compressed else R.string.compress_failed)
                load()
            }
        }
    }

    private fun extractHere(zip: File) {
        val parent = zip.parentFile ?: return
        val dest = FileOps.uniqueTarget(parent, zip.nameWithoutExtension, true)
        busy(true)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { FileOps.unzip(zip, dest) }
            Indexer.markDirty()
            toast(if (ok) R.string.extracted else R.string.extract_failed)
            load()
        }
    }

    private fun showProperties(files: List<File>) {
        if (files.isEmpty()) return
        val density = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(ContextCompat.getColor(this@FilesActivity, R.color.text_primary))
            textSize = 14f
            setLineSpacing(0f, 1.25f)
            val p = (20 * density).toInt()
            setPadding(p, p / 2, p, 0)
        }

        fun render(sizeText: String): String {
            val sb = StringBuilder()
            if (files.size == 1) {
                val f = files[0]
                sb.append(getString(R.string.prop_name)).append(": ").append(f.name).append('\n')
                sb.append(getString(R.string.prop_path)).append(": ").append(f.parent ?: "").append('\n')
                sb.append(getString(R.string.prop_type)).append(": ")
                    .append(if (f.isDirectory) getString(R.string.prop_folder) else FileOps.mimeOf(f)).append('\n')
                sb.append(getString(R.string.prop_size)).append(": ").append(sizeText).append('\n')
                sb.append(getString(R.string.prop_modified)).append(": ").append(FileOps.formatDate(f.lastModified()))
                if (f.isDirectory) {
                    sb.append('\n').append(getString(R.string.prop_contains)).append(": ")
                        .append(getString(R.string.items_count, f.list()?.size ?: 0))
                }
            } else {
                sb.append(getString(R.string.prop_count)).append(": ").append(files.size).append('\n')
                sb.append(getString(R.string.prop_total)).append(": ").append(sizeText)
            }
            return sb.toString()
        }

        tv.text = render("…")
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.properties)
            .setView(tv)
            .setPositiveButton(R.string.ok, null)
            .show()
        lifecycleScope.launch {
            val total = withContext(Dispatchers.IO) { files.sumOf { FileOps.sizeOf(it) } }
            tv.text = render(FileOps.formatSize(total))
        }
    }

    private fun promptName(titleRes: Int, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.name_hint)
            setText(initial)
            setSelection(text.length)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val container = FrameLayout(this).apply {
            setPadding(pad, pad / 3, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(titleRes)
            .setView(container)
            .setPositiveButton(R.string.ok) { _, _ -> onOk(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(res: Int) = toast(getString(res))
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
