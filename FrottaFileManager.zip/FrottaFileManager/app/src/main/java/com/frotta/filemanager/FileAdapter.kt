package com.frotta.filemanager

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.frotta.filemanager.databinding.ItemFileBinding
import java.io.File

class FileAdapter(
    private val onClick: (FileItem) -> Unit,
    private val onLongClick: (FileItem) -> Unit
) : RecyclerView.Adapter<FileAdapter.VH>() {

    class VH(val b: ItemFileBinding) : RecyclerView.ViewHolder(b.root)

    private var items: List<FileItem> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var showPath = false

    fun submit(list: List<FileItem>, showPath: Boolean) {
        items = list
        this.showPath = showPath
        selected.clear()
        notifyDataSetChanged()
    }

    fun selectedCount(): Int = selected.size

    fun selectedFiles(): List<File> =
        items.filter { it.file.path in selected }.map { it.file }

    fun toggle(item: FileItem) {
        val path = item.file.path
        if (!selected.add(path)) selected.remove(path)
        val i = items.indexOfFirst { it.file.path == path }
        if (i >= 0) notifyItemChanged(i)
    }

    fun selectAll() {
        selected.clear()
        items.forEach { selected.add(it.file.path) }
        notifyDataSetChanged()
    }

    fun clearSelection() {
        if (selected.isEmpty()) return
        selected.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemFileBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val b = holder.b
        val ctx = b.root.context

        b.name.text = item.name
        b.meta.text = when {
            showPath -> item.file.parent ?: ""
            item.isDir -> ctx.getString(R.string.items_count, item.childCount) + " · " + FileOps.formatDate(item.modified)
            else -> FileOps.formatSize(item.size) + " · " + FileOps.formatDate(item.modified)
        }

        val kind = FileOps.kindOf(item)
        b.icon.setImageResource(kind.icon)
        b.icon.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, kind.color))

        val isSel = item.file.path in selected
        b.root.isActivated = isSel
        b.check.visibility = if (isSel) View.VISIBLE else View.GONE

        b.root.setOnClickListener { onClick(item) }
        b.root.setOnLongClickListener {
            onLongClick(item)
            true
        }
    }
}
