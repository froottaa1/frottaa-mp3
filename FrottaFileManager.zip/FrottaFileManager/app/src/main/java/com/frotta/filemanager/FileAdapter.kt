package com.frotta.filemanager

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Job
import java.io.File

class FileAdapter(
    private val onClick: (FileItem) -> Unit,
    private val onLongClick: (FileItem) -> Unit
) : RecyclerView.Adapter<FileAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val thumb: ImageView = view.findViewById(R.id.thumb)
        val name: TextView = view.findViewById(R.id.name)
        val meta: TextView = view.findViewById(R.id.meta)
        val check: ImageView = view.findViewById(R.id.check)
        var job: Job? = null
        var path: String? = null
    }

    private var items: List<FileItem> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var showPath = false
    private var grid = false

    fun submit(list: List<FileItem>, showPath: Boolean) {
        items = list
        this.showPath = showPath
        selected.clear()
        notifyDataSetChanged()
    }

    fun setGrid(value: Boolean) {
        if (grid != value) {
            grid = value
            notifyDataSetChanged()
        }
    }

    fun selectedCount(): Int = selected.size

    fun selectedFiles(): List<File> =
        items.filter { it.file.path in selected }.map { it.file }

    fun toggle(item: FileItem) {
        val path = item.file.path
        if (!selected.add(path)) selected.remove(path)
        val i = items.indexOfFirst { it.file.path == path }
        if (i >= 0) notifyItemChanged(i)
    }

    fun selectAll() {
        selected.clear()
        items.forEach { selected.add(it.file.path) }
        notifyDataSetChanged()
    }

    fun clearSelection() {
        if (selected.isEmpty()) return
        selected.clear()
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = if (grid) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (viewType == 1) R.layout.item_file_grid else R.layout.item_file
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun getItemCount(): Int = items.size

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        holder.job = null
        super.onViewRecycled(holder)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val ctx = holder.itemView.context
        holder.job?.cancel()
        holder.job = null

        holder.path = item.file.path
        holder.name.text = item.name
        holder.meta.text = when {
            item.subtitle != null -> item.subtitle
            showPath && !grid -> item.file.parent ?: ""
            item.isDir -> ctx.getString(R.string.items_count, item.childCount) +
                (if (grid) "" else " · " + FileOps.formatDate(item.modified))
            grid -> FileOps.formatSize(item.size)
            else -> FileOps.formatSize(item.size) + " · " + FileOps.formatDate(item.modified)
        }

        val kind = FileOps.kindOf(item)
        holder.icon.setImageResource(kind.icon)
        holder.icon.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, kind.color))
        holder.icon.visibility = View.VISIBLE
        holder.thumb.visibility = View.GONE

        if (!item.isDir && ThumbLoader.supports(kind)) {
            val path = item.file.path
            holder.thumb.scaleType =
                if (kind == FileOps.Kind.APK) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP
            holder.job = ThumbLoader.load(ctx, path, item.modified, kind, if (grid) 320 else 150) { bmp ->
                if (bmp != null && holder.path == path) {
                    holder.thumb.setImageBitmap(bmp)
                    holder.thumb.visibility = View.VISIBLE
                    holder.icon.visibility = View.INVISIBLE
                }
            }
        }

        val isSel = item.file.path in selected
        holder.itemView.isActivated = isSel
        holder.check.visibility = if (isSel) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener {
            onLongClick(item)
            true
        }
    }
}
