package com.frotta.filemanager

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileOps {

    enum class Sort { NAME, DATE, SIZE }

    enum class Kind(@DrawableRes val icon: Int, @ColorRes val color: Int) {
        FOLDER(R.drawable.ic_folder, R.color.c_folder),
        IMAGE(R.drawable.ic_image, R.color.c_image),
        AUDIO(R.drawable.ic_audio, R.color.c_audio),
        VIDEO(R.drawable.ic_video, R.color.c_video),
        ARCHIVE(R.drawable.ic_archive, R.color.c_archive),
        APK(R.drawable.ic_apk, R.color.c_apk),
        DOC(R.drawable.ic_doc, R.color.c_doc),
        OTHER(R.drawable.ic_file, R.color.c_other)
    }

    private val images = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg")
    private val audio = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus", "wma")
    private val video = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv")
    private val archives = setOf("zip", "rar", "7z", "tar", "gz")
    private val docs = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "csv", "md")

    fun kindOf(item: FileItem): Kind {
        if (item.isDir) return Kind.FOLDER
        val ext = item.file.extension.lowercase()
        return when {
            ext in images -> Kind.IMAGE
            ext in audio -> Kind.AUDIO
            ext in video -> Kind.VIDEO
            ext in archives -> Kind.ARCHIVE
            ext == "apk" || ext == "xapk" -> Kind.APK
            ext in docs -> Kind.DOC
            else -> Kind.OTHER
        }
    }

    fun toItem(f: File): FileItem {
        val dir = f.isDirectory
        return FileItem(
            file = f,
            isDir = dir,
            name = f.name,
            size = if (dir) 0L else f.length(),
            modified = f.lastModified(),
            childCount = if (dir) (f.list()?.size ?: 0) else 0
        )
    }

    fun list(dir: File, showHidden: Boolean, sort: Sort): List<FileItem> {
        val children = dir.listFiles() ?: return emptyList()
        val items = children
            .filter { showHidden || !it.name.startsWith(".") }
            .map { toItem(it) }
        val byName = compareBy<FileItem> { !it.isDir }.thenBy { it.name.lowercase() }
        val comparator: Comparator<FileItem> = when (sort) {
            Sort.NAME -> byName
            Sort.DATE -> compareBy<FileItem> { !it.isDir }.thenByDescending { it.modified }
            Sort.SIZE -> compareBy<FileItem> { !it.isDir }.thenByDescending { it.size }.thenBy { it.name.lowercase() }
        }
        return items.sortedWith(comparator)
    }

    suspend fun search(root: File, query: String, showHidden: Boolean, limit: Int = 300): List<FileItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim().lowercase()
            val out = ArrayList<FileItem>()
            val stack = mutableListOf(root)
            while (stack.isNotEmpty() && out.size < limit) {
                ensureActive()
                val dir = stack.removeAt(stack.lastIndex)
                val children = dir.listFiles() ?: continue
                for (f in children) {
                    if (!showHidden && f.name.startsWith(".")) continue
                    if (f.name.lowercase().contains(q)) out.add(toItem(f))
                    if (f.isDirectory) stack.add(f)
                }
            }
            out.sortedWith(compareBy<FileItem> { !it.isDir }.thenBy { it.name.lowercase() })
        }

    private fun isInside(src: File, dest: File): Boolean {
        if (!src.isDirectory) return false
        val s = src.canonicalPath
        val d = dest.canonicalPath
        return d == s || d.startsWith(s + File.separator)
    }

    private fun uniqueTarget(dir: File, name: String, isDir: Boolean): File {
        var t = File(dir, name)
        if (!t.exists()) return t
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0 && !isDir) name.substring(0, dot) else name
        val ext = if (dot > 0 && !isDir) name.substring(dot) else ""
        var i = 1
        while (t.exists()) {
            t = File(dir, "$base ($i)$ext")
            i++
        }
        return t
    }

    fun copy(src: File, destDir: File): Boolean = runCatching {
        require(!isInside(src, destDir))
        val target = uniqueTarget(destDir, src.name, src.isDirectory)
        if (src.isDirectory) {
            src.copyRecursively(target, overwrite = false)
        } else {
            src.copyTo(target, overwrite = false)
            true
        }
    }.getOrDefault(false)

    fun move(src: File, destDir: File): Boolean = runCatching {
        if (src.parentFile?.canonicalPath == destDir.canonicalPath) return@runCatching true
        require(!isInside(src, destDir))
        val target = uniqueTarget(destDir, src.name, src.isDirectory)
        if (src.renameTo(target)) {
            true
        } else {
            val ok = if (src.isDirectory) {
                src.copyRecursively(target, overwrite = false)
            } else {
                src.copyTo(target, overwrite = false)
                true
            }
            if (ok) src.deleteRecursively() else false
        }
    }.getOrDefault(false)

    fun delete(f: File): Boolean = runCatching { f.deleteRecursively() }.getOrDefault(false)

    private fun validName(name: String) =
        name.isNotBlank() && !name.contains('/') && name != "." && name != ".."

    fun mkdir(parent: File, name: String): Boolean {
        val n = name.trim()
        if (!validName(n)) return false
        return runCatching { File(parent, n).mkdir() }.getOrDefault(false)
    }

    fun rename(file: File, newName: String): Boolean {
        val n = newName.trim()
        if (!validName(n)) return false
        val target = File(file.parentFile, n)
        if (target.exists()) return false
        return runCatching { file.renameTo(target) }.getOrDefault(false)
    }

    fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format(Locale.getDefault(), "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.getDefault(), "%.1f MB", mb)
        return String.format(Locale.getDefault(), "%.2f GB", mb / 1024.0)
    }

    private val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    fun formatDate(ms: Long): String = dateFormat.format(Date(ms))

    fun open(ctx: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", file)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, R.string.no_app, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.no_app, Toast.LENGTH_SHORT).show()
        }
    }
}
