package com.frotta.filemanager

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.core.content.ContextCompat
import java.io.File

data class Volume(val name: String, val root: File, val removable: Boolean)

object Storage {

    @Suppress("DEPRECATION")
    fun internalRoot(): File = Environment.getExternalStorageDirectory()

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    fun volumes(ctx: Context): List<Volume> {
        val list = mutableListOf<Volume>()
        val internal = internalRoot()
        list.add(Volume(ctx.getString(R.string.storage), internal, false))
        val dirs = ContextCompat.getExternalFilesDirs(ctx, null)
        for (d in dirs) {
            if (d == null) continue
            val idx = d.path.indexOf("/Android/data")
            if (idx <= 0) continue
            val r = File(d.path.substring(0, idx))
            if (r.path != internal.path && r.exists() && list.none { it.root.path == r.path }) {
                list.add(Volume(ctx.getString(R.string.sd_card), r, true))
            }
        }
        return list
    }

    fun rootFor(ctx: Context, path: String): File =
        volumes(ctx).firstOrNull { path == it.root.path || path.startsWith(it.root.path + "/") }?.root
            ?: internalRoot()

    /** Returns total to free bytes. */
    fun usage(root: File): Pair<Long, Long> {
        return try {
            val s = StatFs(root.path)
            (s.blockCountLong * s.blockSizeLong) to (s.availableBlocksLong * s.blockSizeLong)
        } catch (e: Exception) {
            0L to 0L
        }
    }
}
