package com.frotta.filemanager

import java.io.File

data class FileItem(
    val file: File,
    val isDir: Boolean,
    val name: String,
    val size: Long,
    val modified: Long,
    val childCount: Int,
    val subtitle: String? = null
)
