package com.frotta.filemanager

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.frotta.filemanager.databinding.ItemTileBinding

data class HomeTile(
    val id: String,
    @StringRes val title: Int,
    @DrawableRes val icon: Int,
    @ColorRes val color: Int,
    val subtitle: String?
)

class TileAdapter(private val onClick: (HomeTile) -> Unit) : RecyclerView.Adapter<TileAdapter.VH>() {

    class VH(val b: ItemTileBinding) : RecyclerView.ViewHolder(b.root)

    private var items: List<HomeTile> = emptyList()

    fun submit(list: List<HomeTile>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemTileBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val t = items[position]
        val ctx = holder.b.root.context
        holder.b.icon.setImageResource(t.icon)
        holder.b.icon.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, t.color))
        holder.b.title.setText(t.title)
        holder.b.subtitle.text = t.subtitle ?: ""
        holder.b.root.setOnClickListener { onClick(t) }
    }
}
