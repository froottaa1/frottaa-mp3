package com.frotta.filemanager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.frotta.filemanager.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: FileAdapter

    @Suppress("DEPRECATION")
    private val root: File = Environment.getExternalStorageDirectory()
    private var currentDir: File = root
    private var started = false
    private var showHidden = false
    private var sort = FileOps.Sort.NAME
    private var searching = false

    private var clipboard: List<File> = emptyList()
    private var clipMove = false

    private var loadJob: Job? = null
    private var searchJob: Job? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refreshAccess() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        adapter = FileAdapter(onClick = ::onItemClick, onLongClick = ::onItemLong)
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter

        b.grantButton.setOnClickListener { requestAccess() }
        b.pasteButton.setOnClickListener { paste() }
        b.cancelPasteButton.setOnClickListener {
            clipboard = emptyList()
            updatePasteBar()
        }
        b.pathText.setOnClickListener { if (!searching) goUp() }

        b.toolbar.setNavigationOnClickListener {
            if (adapter.selectedCount() > 0) clearSelection() else goUp()
        }
        b.toolbar.setOnMenuItemClickListener { onMenu(it) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    adapter.selectedCount() > 0 -> clearSelection()
                    searching -> collapseSearch()
                    hasAccess() && currentDir != root -> goUp()
                    else -> finish()
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        refreshAccess()
    }

    // ---------------------------------------------------------------- permissions

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            permLauncher.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    private fun refreshAccess() {
        val ok = hasAccess()
        b.permissionLayout.visibility = if (ok) View.GONE else View.VISIBLE
        b.contentLayout.visibility = if (ok) View.VISIBLE else View.GONE
        if (ok && !started) {
            started = true
            currentDir = root
            load()
        } else {
            updateToolbar()
        }
    }

    // ---------------------------------------------------------------- loading

    private fun busy(on: Boolean) {
        b.progress.visibility = if (on) View.VISIBLE else View.INVISIBLE
    }

    private fun pathLabel(dir: File): String {
        val storage = getString(R.string.storage)
        val rel = runCatching { dir.relativeTo(root).path }.getOrDefault(dir.path)
        return if (rel.isEmpty()) storage else storage + " › " + rel.replace(File.separator, " › ")
    }

    private fun load(updateBar: Boolean = true) {
        loadJob?.cancel()
        searchJob?.cancel()
        val dir = currentDir
        busy(true)
        loadJob = lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { FileOps.list(dir, showHidden, sort) }
            adapter.submit(list, false)
            b.emptyText.setText(R.string.empty_folder)
            b.emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            b.pathText.text = pathLabel(dir)
            busy(false)
            if (updateBar) updateToolbar()
        }
    }

    private fun goUp() {
        if (currentDir == root) return
        currentDir = currentDir.parentFile ?: root
        load()
    }

    // ---------------------------------------------------------------- toolbar & menu

    private fun updateToolbar() {
        val tb = b.toolbar
        tb.menu.clear()
        if (!hasAccess()) {
            tb.title = getString(R.string.app_name)
            tb.navigationIcon = null
            return
        }
        val sel = adapter.selectedCount()
        if (sel > 0) {
            tb.inflateMenu(R.menu.selection_menu)
            tb.title = getString(R.string.selected_count, sel)
            tb.setNavigationIcon(R.drawable.ic_close)
            tb.menu.findItem(R.id.action_rename).isVisible = sel == 1
        } else {
            tb.inflateMenu(R.menu.main_menu)
            tb.title = if (currentDir == root) getString(R.string.app_name) else currentDir.name
            if (currentDir == root) tb.navigationIcon = null else tb.setNavigationIcon(R.drawable.ic_up)
            setupSearch(tb.menu.findItem(R.id.action_search))
            tb.menu.findItem(R.id.action_hidden).isChecked = showHidden
            val sortId = when (sort) {
                FileOps.Sort.NAME -> R.id.sort_name
                FileOps.Sort.DATE -> R.id.sort_date
                FileOps.Sort.SIZE -> R.id.sort_size
            }
            tb.menu.findItem(sortId).isChecked = true
        }
    }

    private fun setupSearch(item: MenuItem) {
        val sv = item.actionView as SearchView
        sv.queryHint = getString(R.string.search_hint)
        sv.maxWidth = Int.MAX_VALUE
        sv.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)?.apply {
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
            setHintTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_secondary))
        }
        sv.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                runSearch(query.orEmpty())
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (searching) runSearch(newText.orEmpty())
                return true
            }
        })
        item.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
            override fun onMenuItemActionExpand(item: MenuItem): Boolean {
                searching = true
                return true
            }

            override fun onMenuItemActionCollapse(item: MenuItem): Boolean {
                searching = false
                searchJob?.cancel()
                load()
                return true
            }
        })
    }

    private fun collapseSearch() {
        val item = b.toolbar.menu.findItem(R.id.action_search)
        if (item != null && item.isActionViewExpanded) item.collapseActionView() else {
            searching = false
            load()
        }
    }

    private fun runSearch(query: String) {
        searchJob?.cancel()
        loadJob?.cancel()
        if (query.isBlank()) {
            load(updateBar = false)
            return
        }
        val base = currentDir
        busy(true)
        searchJob = lifecycleScope.launch {
            delay(250)
            val res = FileOps.search(base, query, showHidden)
            adapter.submit(res, true)
            b.emptyText.setText(R.string.no_results)
            b.emptyText.visibility = if (res.isEmpty()) View.VISIBLE else View.GONE
            b.pathText.text = getString(R.string.search_results, res.size)
            busy(false)
        }
    }

    private fun onMenu(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_new_folder -> promptName(R.string.new_folder, "") { name ->
                toast(if (FileOps.mkdir(currentDir, name)) R.string.created else R.string.name_invalid)
                load()
            }
            R.id.sort_name -> { sort = FileOps.Sort.NAME; load() }
            R.id.sort_date -> { sort = FileOps.Sort.DATE; load() }
            R.id.sort_size -> { sort = FileOps.Sort.SIZE; load() }
            R.id.action_hidden -> { showHidden = !showHidden; load() }
            R.id.action_refresh -> load()
            R.id.action_copy -> setClipboard(move = false)
            R.id.action_cut -> setClipboard(move = true)
            R.id.action_delete -> confirmDelete()
            R.id.action_rename -> promptRename()
            R.id.action_select_all -> {
                adapter.selectAll()
                updateToolbar()
            }
            else -> return false
        }
        return true
    }

    // ---------------------------------------------------------------- item events

    private fun onItemClick(item: FileItem) {
        if (adapter.selectedCount() > 0) {
            adapter.toggle(item)
            updateToolbar()
            return
        }
        if (item.isDir) {
            currentDir = item.file
            if (searching) collapseSearch() else load()
        } else {
            FileOps.open(this, item.file)
        }
    }

    private fun onItemLong(item: FileItem) {
        if (searching) return
        adapter.toggle(item)
        updateToolbar()
    }

    private fun clearSelection() {
        adapter.clearSelection()
        updateToolbar()
    }

    // ---------------------------------------------------------------- actions

    private fun setClipboard(move: Boolean) {
        clipboard = adapter.selectedFiles()
        clipMove = move
        adapter.clearSelection()
        updateToolbar()
        updatePasteBar()
    }

    private fun updatePasteBar() {
        b.pasteBar.visibility = if (clipboard.isEmpty()) View.GONE else View.VISIBLE
        b.pasteInfo.text = getString(if (clipMove) R.string.clip_move else R.string.clip_copy, clipboard.size)
    }

    private fun paste() {
        val files = clipboard
        if (files.isEmpty()) return
        val move = clipMove
        val dest = currentDir
        busy(true)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                files.count { if (move) FileOps.move(it, dest) else FileOps.copy(it, dest) }
            }
            clipboard = emptyList()
            updatePasteBar()
            toast(getString(R.string.done_result, ok, files.size - ok))
            load()
        }
    }

    private fun confirmDelete() {
        val files = adapter.selectedFiles()
        if (files.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.delete)
            .setMessage(getString(R.string.delete_message, files.size))
            .setPositiveButton(R.string.delete) { _, _ -> doDelete(files) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun doDelete(files: List<File>) {
        busy(true)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { files.count { FileOps.delete(it) } }
            toast(getString(R.string.done_result, ok, files.size - ok))
            load()
        }
    }

    private fun promptRename() {
        val file = adapter.selectedFiles().firstOrNull() ?: return
        promptName(R.string.rename, file.name) { name ->
            toast(if (FileOps.rename(file, name)) R.string.renamed else R.string.name_invalid)
            load()
        }
    }

    private fun promptName(titleRes: Int, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.folder_name)
            setText(initial)
            setSelection(text.length)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val container = FrameLayout(this).apply {
            setPadding(pad, pad / 3, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(titleRes)
            .setView(container)
            .setPositiveButton(R.string.ok) { _, _ -> onOk(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(res: Int) = toast(getString(res))
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
