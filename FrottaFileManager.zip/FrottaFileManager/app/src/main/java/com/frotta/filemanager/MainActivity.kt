package com.frotta.filemanager

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import com.frotta.filemanager.databinding.ActivityMainBinding
import com.frotta.filemanager.databinding.ItemStorageBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var catAdapter: TileAdapter
    private lateinit var toolsAdapter: TileAdapter
    private var purged = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refreshAccess() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.toolbar.inflateMenu(R.menu.home_menu)
        b.toolbar.setOnMenuItemClickListener { onMenu(it) }

        catAdapter = TileAdapter(::onTile)
        toolsAdapter = TileAdapter(::onTile)
        b.categoriesRecycler.layoutManager = GridLayoutManager(this, 3)
        b.categoriesRecycler.adapter = catAdapter
        b.toolsRecycler.layoutManager = GridLayoutManager(this, 4)
        b.toolsRecycler.adapter = toolsAdapter

        b.grantButton.setOnClickListener { requestAccess() }
        b.searchPill.setOnClickListener { openSearch() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Indexer.version.collect { buildTiles() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshAccess()
    }

    // ------------------------------------------------------------ access

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            permLauncher.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    private fun refreshAccess() {
        val ok = Storage.hasAccess(this)
        b.permissionLayout.visibility = if (ok) View.GONE else View.VISIBLE
        b.homeScroll.visibility = if (ok) View.VISIBLE else View.GONE
        b.toolbar.menu.findItem(R.id.action_search)?.isVisible = ok
        b.toolbar.menu.findItem(R.id.action_use_trash)?.isChecked = Prefs.useTrash(this)
        if (!ok) return

        if (!purged) {
            purged = true
            lifecycleScope.launch(Dispatchers.IO) { TrashManager.purgeOld(30) }
        }
        Indexer.ensure(this)
        buildStorage()
        buildFavorites()
        buildTiles()
    }

    // ------------------------------------------------------------ menu / actions

    private fun onMenu(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_search -> openSearch()
            R.id.action_use_trash -> {
                val now = !Prefs.useTrash(this)
                Prefs.setUseTrash(this, now)
                item.isChecked = now
            }
            R.id.action_rescan -> {
                Indexer.rescan(this)
                buildTiles()
            }
            else -> return false
        }
        return true
    }

    private fun openSearch() {
        startActivity(FilesActivity.simple(this, FilesActivity.MODE_SEARCH))
    }

    private fun onTile(t: HomeTile) {
        when (t.id) {
            "RECENT" -> startActivity(FilesActivity.simple(this, FilesActivity.MODE_RECENT))
            "LARGE" -> startActivity(FilesActivity.simple(this, FilesActivity.MODE_LARGE))
            "APPS" -> startActivity(Intent(this, AppsActivity::class.java))
            "TRASH" -> startActivity(Intent(this, TrashActivity::class.java))
            else -> runCatching { Category.valueOf(t.id) }.getOrNull()?.let {
                startActivity(FilesActivity.category(this, it))
            }
        }
    }

    // ------------------------------------------------------------ building the screen

    private fun buildStorage() {
        b.storageContainer.removeAllViews()
        for (v in Storage.volumes(this)) {
            val sb = ItemStorageBinding.inflate(layoutInflater, b.storageContainer, false)
            val (total, free) = Storage.usage(v.root)
            val used = (total - free).coerceAtLeast(0)
            sb.storageName.text = v.name
            sb.storageUsed.text = getString(R.string.used_of, FileOps.formatSize(used), FileOps.formatSize(total))
            sb.usageBar.progress = if (total > 0) (used * 1000 / total).toInt() else 0
            sb.storageIcon.setImageResource(if (v.removable) R.drawable.ic_archive else R.drawable.ic_storage)
            sb.root.setOnClickListener { startActivity(FilesActivity.dir(this, v.root.path)) }
            b.storageContainer.addView(sb.root)
        }
    }

    private fun buildFavorites() {
        b.favContainer.removeAllViews()
        val favs = Prefs.favorites(this).filter { File(it).isDirectory }
        b.favSection.visibility = if (favs.isEmpty()) View.GONE else View.VISIBLE
        val pad = (14 * resources.displayMetrics.density).toInt()
        val gap = (8 * resources.displayMetrics.density).toInt()
        for (path in favs) {
            val tv = TextView(this).apply {
                text = File(path).name
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                textSize = 14f
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.bg_pill)
                setPadding(pad * 3 / 2, pad * 2 / 3, pad * 3 / 2, pad * 2 / 3)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = gap }
                setOnClickListener { startActivity(FilesActivity.dir(this@MainActivity, path)) }
                setOnLongClickListener {
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle(File(path).name)
                        .setMessage(R.string.fav_removed)
                        .setPositiveButton(R.string.ok) { _, _ ->
                            Prefs.toggleFavorite(this@MainActivity, path)
                            buildFavorites()
                        }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                    true
                }
            }
            b.favContainer.addView(tv)
        }
    }

    private fun buildTiles() {
        if (!Storage.hasAccess(this)) return
        val cats = Category.values().map { c ->
            val (n, s) = Indexer.stat(c)
            HomeTile(
                c.name, c.title, c.icon, c.color,
                if (Indexer.ready) getString(R.string.tile_sub, n, FileOps.formatSize(s)) else "…"
            )
        }
        catAdapter.submit(cats)

        val trashCount = TrashManager.entries().size
        toolsAdapter.submit(
            listOf(
                HomeTile("RECENT", R.string.tool_recent, R.drawable.ic_clock, R.color.violet, null),
                HomeTile("LARGE", R.string.tool_large, R.drawable.ic_chart, R.color.orange, null),
                HomeTile("APPS", R.string.tool_apps, R.drawable.ic_apps, R.color.c_apk, null),
                HomeTile(
                    "TRASH", R.string.tool_trash, R.drawable.ic_delete, R.color.pink,
                    if (trashCount > 0) trashCount.toString() else null
                )
            )
        )
    }
}
