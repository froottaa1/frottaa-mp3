package com.frotta.filemanager

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.frotta.filemanager.databinding.ActivityTrashBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class TrashActivity : AppCompatActivity() {

    private lateinit var b: ActivityTrashBinding
    private lateinit var adapter: FileAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTrashBinding.inflate(layoutInflater)
        setContentView(b.root)

        adapter = FileAdapter(
            onClick = { adapter.toggle(it); updateBar() },
            onLongClick = { adapter.toggle(it); updateBar() }
        )
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter

        b.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
        b.toolbar.inflateMenu(R.menu.trash_menu)
        b.toolbar.setOnMenuItemClickListener { onMenu(it) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (adapter.selectedCount() > 0) {
                    adapter.clearSelection()
                    updateBar()
                } else finish()
            }
        })
        load()
    }

    private fun load() {
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                TrashManager.entries().map { e ->
                    val f = TrashManager.fileFor(e)
                    FileItem(
                        file = f,
                        isDir = e.isDir,
                        name = e.name,
                        size = if (e.isDir) 0L else f.length(),
                        modified = e.deletedAt,
                        childCount = 0,
                        subtitle = e.originalPath
                    )
                }
            }
            adapter.submit(items, false)
            b.emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            updateBar()
        }
    }

    private fun updateBar() {
        val sel = adapter.selectedCount()
        b.toolbar.title = if (sel > 0) getString(R.string.selected_count, sel) else getString(R.string.tool_trash)
        b.toolbar.setNavigationIcon(if (sel > 0) R.drawable.ic_close else R.drawable.ic_up)
        b.toolbar.menu.findItem(R.id.action_restore)?.isVisible = sel > 0
        b.toolbar.menu.findItem(R.id.action_delete_forever)?.isVisible = sel > 0
    }

    private fun selectedEntries(): List<TrashEntry> {
        val ids = adapter.selectedFiles().map(File::getName).toSet()
        return TrashManager.entries().filter { it.id in ids }
    }

    private fun onMenu(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_restore -> {
                val entries = selectedEntries()
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { entries.forEach { TrashManager.restore(it) } }
                    Indexer.markDirty()
                    Toast.makeText(this@TrashActivity, R.string.restored, Toast.LENGTH_SHORT).show()
                    load()
                }
            }
            R.id.action_delete_forever -> {
                val entries = selectedEntries()
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.delete_forever)
                    .setMessage(getString(R.string.delete_message, entries.size))
                    .setPositiveButton(R.string.delete) { _, _ ->
                        lifecycleScope.launch {
                            withContext(Dispatchers.IO) { entries.forEach { TrashManager.deleteForever(it) } }
                            load()
                        }
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
            R.id.action_select_all -> {
                adapter.selectAll()
                updateBar()
            }
            R.id.action_empty -> MaterialAlertDialogBuilder(this)
                .setTitle(R.string.empty_trash)
                .setMessage(R.string.confirm_empty)
                .setPositiveButton(R.string.delete) { _, _ ->
                    lifecycleScope.launch {
                        withContext(Dispatchers.IO) { TrashManager.empty() }
                        load()
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
            else -> return false
        }
        return true
    }
}
