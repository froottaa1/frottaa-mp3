# Frotta Clone

Cross-brand Android-to-Android transfer MVP (Kotlin + Jetpack Compose).

## Included
- Sender / Receiver role selection
- Material 3 UI with system dark-mode support
- Local TCP receiver and sender using a length-prefixed binary protocol
- File picker for selecting multiple files
- Per-file and overall byte progress
- Receiver pairing QR display (contains local IP and port)
- Wi-Fi Direct peer discovery/connection helper
- Contacts export helper (VCF)

## Important limitations
This is a starter MVP, not a certified or device-lab-tested migration product.
The QR currently encodes the receiver's IP/port; both devices must already share a
local link (Wi-Fi Direct group or same local Wi-Fi). The Wi-Fi Direct helper exposes
peer discovery and connection, but OEM behavior and Android permission prompts vary.
For a production app, add a peer-selection screen and obtain the group-owner address
after connection before showing the QR.

Android restricts call-log and SMS access. SMS permissions are tightly controlled by
Google Play policy and, on recent Android versions, SMS import/restore generally
requires being the default SMS handler. Call-log permissions are also policy-restricted.
This project deliberately does not silently read or write these records.
Apps' private data, credentials, and protected application state cannot be copied by
an ordinary third-party app. APK extraction is not universal (split APKs, licensing,
signatures, and package restrictions apply).

## Build
Open this folder in Android Studio (JDK 17), allow Gradle sync, then run on two Android
devices. Grant nearby Wi-Fi and file-picker access when prompted. On the receiver,
start receiving and share its displayed IP/port QR. Ensure the sender can reach that
address over the local link. The sender can also type the receiver address manually.

## Protocol
TCP port 8988. Each file is sent as:
- UTF filename length (DataOutputStream.writeUTF)
- file size (Long)
- raw bytes
A zero-length filename terminates the session.
