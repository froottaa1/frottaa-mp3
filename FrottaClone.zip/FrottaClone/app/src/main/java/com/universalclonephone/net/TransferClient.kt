package com.frottaclone.net

import android.content.Context
import android.net.Uri
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket

class TransferClient(private val context: Context) {
    fun send(host: String, port: Int, uris: List<Uri>, onProgress: (Float) -> Unit) {
        Socket().use { socket ->
            socket.connect(InetSocketAddress(host, port), 15_000)
            val output = DataOutputStream(socket.getOutputStream())
            val resolver = context.contentResolver
            val total = uris.sumOf { uri ->
                resolver.openAssetFileDescriptor(uri, "r")?.use { it.length }?.coerceAtLeast(0) ?: 0L
            }.coerceAtLeast(1L)
            var overall = 0L
            uris.forEach { uri ->
                val name = resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "transfer_${System.currentTimeMillis()}"
                val size = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                if (size < 0) throw IllegalStateException("Cannot determine file size: $name")
                output.writeUTF(name)
                output.writeLong(size)
                resolver.openInputStream(uri).use { input ->
                    requireNotNull(input)
                    val buffer = ByteArray(64 * 1024)
                    var fileSent = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        fileSent += n
                        overall += n
                        onProgress((overall.toFloat() / total).coerceIn(0f, 1f))
                    }
                    if (fileSent != size) throw IllegalStateException("File size changed during transfer")
                }
            }
            output.writeUTF("")
            output.flush()
        }
        onProgress(1f)
    }
}
