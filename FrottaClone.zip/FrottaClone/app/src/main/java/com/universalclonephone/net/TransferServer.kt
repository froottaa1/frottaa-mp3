package com.frottaclone.net

import android.content.Context
import android.os.Environment
import java.io.DataInputStream
import java.io.File
import java.net.ServerSocket
import java.net.Inet4Address
import java.net.NetworkInterface

class TransferServer(private val context: Context) {
    companion object { const val PORT = 8988 }

    fun localIpv4(): String {
        val interfaces = NetworkInterface.getNetworkInterfaces()
        while (interfaces.hasMoreElements()) {
            val addresses = interfaces.nextElement().inetAddresses
            while (addresses.hasMoreElements()) {
                val a = addresses.nextElement()
                if (!a.isLoopbackAddress && a is Inet4Address) return a.hostAddress ?: continue
            }
        }
        return "192.168.49.1"
    }

    fun receive(onProgress: (String, Float) -> Unit) {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "UniversalClone")
        dir.mkdirs()
        ServerSocket(PORT).use { server ->
            server.soTimeout = 120_000
            server.accept().use { socket ->
                val input = DataInputStream(socket.getInputStream())
                while (true) {
                    val name = input.readUTF()
                    if (name.isEmpty()) break
                    val safeName = File(name).name
                    val size = input.readLong()
                    if (size < 0) throw IllegalArgumentException("Invalid file size")
                    val outFile = File(dir, safeName)
                    outFile.outputStream().buffered().use { out ->
                        val buffer = ByteArray(64 * 1024)
                        var remaining = size
                        var copied = 0L
                        while (remaining > 0) {
                            val count = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                            if (count < 0) throw IllegalStateException("Connection interrupted")
                            out.write(buffer, 0, count)
                            remaining -= count
                            copied += count
                            onProgress(safeName, if (size == 0L) 1f else copied.toFloat() / size)
                        }
                    }
                    onProgress(safeName, 1f)
                }
            }
        }
    }
}
