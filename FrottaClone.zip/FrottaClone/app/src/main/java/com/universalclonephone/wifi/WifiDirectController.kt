package com.frottaclone.wifi

import android.content.Context
import android.net.wifi.p2p.*
import android.os.Looper

/**
 * Wi-Fi Direct discovery/connection primitive.
 * Register a BroadcastReceiver for WIFI_P2P_PEERS_CHANGED_ACTION and
 * WIFI_P2P_CONNECTION_CHANGED_ACTION in the Activity before using this helper.
 */
class WifiDirectController(context: Context) {
    private val manager = context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val channel = manager.initialize(context, Looper.getMainLooper(), null)

    fun discover(onResult: (Boolean, String?) -> Unit) {
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = onResult(true, null)
            override fun onFailure(reason: Int) = onResult(false, "discoverPeers failed: $reason")
        })
    }

    fun requestPeers(onPeers: (Collection<WifiP2pDevice>) -> Unit) {
        manager.requestPeers(channel) { list -> onPeers(list.deviceList) }
    }

    fun connect(device: WifiP2pDevice, onResult: (Boolean, String?) -> Unit) {
        val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = onResult(true, null)
            override fun onFailure(reason: Int) = onResult(false, "connect failed: $reason")
        })
    }

    fun connectionInfo(onInfo: (WifiP2pInfo) -> Unit) {
        manager.requestConnectionInfo(channel) { info -> onInfo(info) }
    }
}
