package com.frottaclone.data

import android.content.Context
import android.provider.ContactsContract
import java.io.File

/** Exports visible contacts to standard vCard 3.0; requires READ_CONTACTS consent. */
object ContactsExporter {
    fun exportVcf(context: Context, destination: File): Int {
        val uri = ContactsContract.Contacts.CONTENT_URI
        val cursor = context.contentResolver.query(uri, null, null, null, null) ?: return 0
        var count = 0
        destination.bufferedWriter().use { writer ->
            cursor.use { c ->
                val idCol = c.getColumnIndex(ContactsContract.Contacts._ID)
                val hasPhoneCol = c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)
                while (c.moveToNext()) {
                    val id = c.getString(idCol)
                    val lookup = android.net.Uri.withAppendedPath(
                        ContactsContract.Contacts.CONTENT_VCARD_URI, id
                    )
                    try {
                        context.contentResolver.openAssetFileDescriptor(lookup, "r")?.use { afd ->
                            afd.createInputStream().bufferedReader().use { reader -> writer.write(reader.readText()) }
                        }
                        count++
                    } catch (_: Exception) { /* Skip contacts the provider cannot export. */ }
                }
            }
        }
        return count
    }
}
