package com.frottaclone

import android.Manifest
import android.content.pm.PackageManager
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.frottaclone.net.TransferClient
import com.frottaclone.net.TransferServer
import com.frottaclone.util.QrCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CloneApp() } }
    }

    @Composable
    private fun CloneApp() {
        var role by remember { mutableStateOf<String?>(null) }
        var address by remember { mutableStateOf("") }
        var status by remember { mutableStateOf("Ready") }
        var progress by remember { mutableFloatStateOf(0f) }
        var received by remember { mutableStateOf<List<String>>(emptyList()) }
        var selected by remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }
        var receiverInfo by remember { mutableStateOf<String?>(null) }
        val scope = rememberCoroutineScope()
        val picker = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenMultipleDocuments()
        ) { selected = it ?: emptyList() }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { }

        fun requestNearbyPermissions() {
            val permissions = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            permissionLauncher.launch(permissions)
        }

        Surface(Modifier.fillMaxSize()) {
            if (role == null) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.PhoneAndroid, null, Modifier.size(64.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Frotta Clone", style = MaterialTheme.typography.headlineMedium)
                    Text("نقل البيانات بين هواتف أندرويد من شركات مختلفة")
                    Spacer(Modifier.height(32.dp))
                    Button(onClick = { role = "receiver"; requestNearbyPermissions() },
                        modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp))
                        Text("هذا هو الهاتف الجديد (استقبال)")
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { role = "sender"; requestNearbyPermissions() },
                        modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Upload, null); Spacer(Modifier.width(8.dp))
                        Text("هذا هو الهاتف القديم (إرسال)")
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { role = null }) { Icon(Icons.Default.ArrowBack, null) }
                        Text(if (role == "receiver") "استقبال البيانات" else "إرسال البيانات",
                            style = MaterialTheme.typography.titleLarge)
                    }
                    if (role == "receiver") {
                        Text("ابدأ الاستقبال، ثم أدخل عنوان الاتصال في الهاتف المرسل.")
                        Button(onClick = {
                            scope.launch(Dispatchers.IO) {
                                try {
                                    val server = TransferServer(this@MainActivity)
                                    val ip = server.localIpv4()
                                    receiverInfo = "$ip:${TransferServer.PORT}"
                                    status = "بانتظار اتصال الهاتف الآخر"
                                    server.receive { name, fraction ->
                                        runOnUiThread {
                                            progress = fraction
                                            received = received + name
                                        }
                                    }
                                    runOnUiThread { status = "انتهى الاستقبال" }
                                } catch (e: Exception) {
                                    runOnUiThread { status = "خطأ: ${e.message}" }
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("بدء الاستقبال") }
                        receiverInfo?.let { info ->
                            Spacer(Modifier.height(12.dp))
                            Text("عنوان الاتصال: $info")
                            QrCode(info)?.let { Image(it.asImageBitmap(), null, Modifier.size(220.dp).align(Alignment.CenterHorizontally)) }
                        }
                    } else {
                        OutlinedTextField(value = address, onValueChange = { address = it },
                            label = { Text("عنوان المستقبل (IP:Port)") },
                            placeholder = { Text("192.168.49.1:8988") },
                            modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth()) { Text("اختيار الصور والفيديوهات والمستندات") }
                        Text("${selected.size} ملف محدد")
                        Button(enabled = selected.isNotEmpty() && address.contains(":"),
                            onClick = {
                                scope.launch(Dispatchers.IO) {
                                    try {
                                        val parts = address.split(":")
                                        val client = TransferClient(this@MainActivity)
                                        client.send(parts[0], parts[1].toInt(), selected) { p ->
                                            runOnUiThread { progress = p }
                                        }
                                        runOnUiThread { status = "اكتمل الإرسال" }
                                    } catch (e: Exception) {
                                        runOnUiThread { status = "خطأ: ${e.message}" }
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("بدء النقل") }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(status)
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    Text("${(progress * 100).toInt()}%")
                    if (received.isNotEmpty()) {
                        Text("الملفات المستلمة:")
                        LazyColumn { items(received) { Text("• $it") } }
                    }
                }
            }
        }
    }
}
