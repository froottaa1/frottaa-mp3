package com.frottafils.app.data

data class Technician(
    val id: Long,
    val name: String,
    val phone: String,
    val specialty: String,
    val type: String,
    val address: String,
    val bio: String,
    val ratingSum: Int,
    val ratingCount: Int
) {
    val rating: Float
        get() = if (ratingCount == 0) 0f else ratingSum.toFloat() / ratingCount

    companion object {
        const val TYPE_HARDWARE = "HARDWARE"
        const val TYPE_SOFTWARE = "SOFTWARE"
    }
}
