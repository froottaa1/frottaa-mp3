package com.frottafils.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.frottafils.app.data.DbHelper
import com.frottafils.app.data.Technician
import com.frottafils.app.databinding.ActivityLoginBinding
import com.frottafils.app.util.Session

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var db: DbHelper
    private lateinit var type: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DbHelper(this)
        type = intent.getStringExtra(EXTRA_TYPE) ?: Technician.TYPE_HARDWARE

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.tvTitle.setText(
            if (type == Technician.TYPE_SOFTWARE) R.string.login_title_software
            else R.string.login_title_hardware
        )

        binding.btnLogin.setOnClickListener { attemptLogin() }
        binding.btnRegister.setOnClickListener {
            startActivity(
                Intent(this, RegisterActivity::class.java).putExtra(EXTRA_TYPE, type)
            )
        }
    }

    private fun attemptLogin() {
        binding.tilPhone.error = null
        binding.tilPassword.error = null

        val phone = binding.etPhone.text?.toString()?.trim().orEmpty()
        val password = binding.etPassword.text?.toString().orEmpty()

        if (phone.isEmpty()) {
            binding.tilPhone.error = getString(R.string.err_required)
            return
        }
        if (password.isEmpty()) {
            binding.tilPassword.error = getString(R.string.err_required)
            return
        }

        val tech = db.login(phone, password)
        when {
            tech == null ->
                Toast.makeText(this, R.string.err_login, Toast.LENGTH_SHORT).show()
            tech.type != type ->
                Toast.makeText(this, R.string.err_wrong_type, Toast.LENGTH_LONG).show()
            else -> {
                Session.setTechId(this, tech.id)
                Nav.openProfile(this)
            }
        }
    }

    companion object {
        const val EXTRA_TYPE = "extra_type"
    }
}
