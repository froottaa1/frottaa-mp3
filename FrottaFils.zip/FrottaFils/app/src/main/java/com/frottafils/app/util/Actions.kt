package com.frottafils.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.frottafils.app.R

object Actions {

    /** فتح تطبيق الاتصال بالرقم */
    fun call(ctx: Context, phone: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null))
        start(ctx, intent)
    }

    /** مراسلة واتساب فورية (الرقم بصيغة دولية بدون +) */
    fun whatsapp(ctx: Context, phone: String) {
        var digits = phone.filter { it.isDigit() }
        if (digits.startsWith("00")) digits = digits.substring(2)
        val text = Uri.encode(ctx.getString(R.string.whatsapp_greeting))
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=$text"))
        start(ctx, intent)
    }

    /** فتح العنوان على الخريطة */
    fun map(ctx: Context, address: String) {
        val geo = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(address)))
        try {
            ctx.startActivity(geo)
        } catch (e: ActivityNotFoundException) {
            val web = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(address))
            )
            start(ctx, web)
        }
    }

    private fun start(ctx: Context, intent: Intent) {
        try {
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, R.string.cannot_open, Toast.LENGTH_SHORT).show()
        }
    }
}
