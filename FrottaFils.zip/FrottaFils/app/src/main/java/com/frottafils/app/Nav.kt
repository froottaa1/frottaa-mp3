package com.frottafils.app

import android.app.Activity
import android.content.Intent

object Nav {
    /** يفتح الملف الشخصي ويجعل الشاشة الرئيسية خلفه (يزيل شاشات الدخول/التسجيل من المكدس) */
    fun openProfile(activity: Activity) {
        val main = Intent(activity, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        val profile = Intent(activity, ProfileActivity::class.java)
        activity.startActivities(arrayOf(main, profile))
        activity.finish()
    }
}
