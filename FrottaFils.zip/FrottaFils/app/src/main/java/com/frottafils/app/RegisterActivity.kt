package com.frottafils.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.frottafils.app.data.DbHelper
import com.frottafils.app.data.Technician
import com.frottafils.app.databinding.ActivityRegisterBinding
import com.frottafils.app.util.Session

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var db: DbHelper
    private lateinit var type: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DbHelper(this)
        type = intent.getStringExtra(LoginActivity.EXTRA_TYPE) ?: Technician.TYPE_HARDWARE

        binding.toolbar.setNavigationOnClickListener { finish() }
        if (type == Technician.TYPE_SOFTWARE) {
            binding.toolbar.setTitle(R.string.register_title_software)
            binding.tilSpecialty.hint = getString(R.string.hint_specialty_software)
        } else {
            binding.toolbar.setTitle(R.string.register_title_hardware)
            binding.tilSpecialty.hint = getString(R.string.hint_specialty_hardware)
        }

        binding.btnRegister.setOnClickListener { submit() }
    }

    private fun submit() {
        binding.tilName.error = null
        binding.tilPhone.error = null
        binding.tilSpecialty.error = null
        binding.tilAddress.error = null
        binding.tilPassword.error = null
        binding.tilConfirm.error = null

        val name = binding.etName.text?.toString()?.trim().orEmpty()
        val phone = binding.etPhone.text?.toString()?.trim().orEmpty()
        val specialty = binding.etSpecialty.text?.toString()?.trim().orEmpty()
        val address = binding.etAddress.text?.toString()?.trim().orEmpty()
        val bio = binding.etBio.text?.toString()?.trim().orEmpty()
        val password = binding.etPassword.text?.toString().orEmpty()
        val confirm = binding.etConfirm.text?.toString().orEmpty()

        if (name.isEmpty()) {
            binding.tilName.error = getString(R.string.err_required); return
        }
        if (phone.count { it.isDigit() } < 8) {
            binding.tilPhone.error = getString(R.string.err_phone); return
        }
        if (specialty.isEmpty()) {
            binding.tilSpecialty.error = getString(R.string.err_required); return
        }
        if (address.isEmpty()) {
            binding.tilAddress.error = getString(R.string.err_required); return
        }
        if (password.length < 6) {
            binding.tilPassword.error = getString(R.string.err_password_short); return
        }
        if (password != confirm) {
            binding.tilConfirm.error = getString(R.string.err_password_match); return
        }

        val id = db.register(name, phone, password, specialty, type, address, bio)
        if (id < 0) {
            binding.tilPhone.error = getString(R.string.err_phone_exists)
            return
        }
        Session.setTechId(this, id)
        Nav.openProfile(this)
    }
}
