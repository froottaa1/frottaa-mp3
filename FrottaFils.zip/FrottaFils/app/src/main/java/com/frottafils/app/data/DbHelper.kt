package com.frottafils.app.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

class DbHelper(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                specialty TEXT NOT NULL,
                type TEXT NOT NULL,
                address TEXT NOT NULL,
                bio TEXT NOT NULL DEFAULT '',
                rating_sum INTEGER NOT NULL DEFAULT 0,
                rating_count INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        seed(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    /** بيانات تجريبية (أرقام وهمية) لعرض شكل التطبيق. كلمة مرور الجميع: 123456 */
    private fun seed(db: SQLiteDatabase) {
        val H = Technician.TYPE_HARDWARE
        val S = Technician.TYPE_SOFTWARE
        data class Seed(
            val name: String, val phone: String, val specialty: String, val type: String,
            val address: String, val bio: String, val sum: Int, val count: Int
        )

        val list = listOf(
            Seed("أحمد حسن", "201000000001", "كهربائي منازل", H, "القاهرة - مدينة نصر", "خبرة 10 سنوات في تأسيس وصيانة الكهرباء.", 47, 10),
            Seed("محمود سعيد", "201000000002", "سباكة وتمديدات", H, "الجيزة - الدقي", "إصلاح التسريبات وتركيب الأدوات الصحية.", 88, 20),
            Seed("خالد إبراهيم", "201000000003", "تكييف وتبريد", H, "القاهرة - المعادي", "تركيب وصيانة وشحن غاز جميع أنواع التكييفات.", 134, 30),
            Seed("يوسف علي", "201000000004", "غسالات وثلاجات", H, "الإسكندرية - سموحة", "صيانة الأجهزة المنزلية بقطع غيار أصلية.", 55, 12),
            Seed("مصطفى كمال", "201000000005", "سوفتوير موبايلات", S, "القاهرة - شبرا", "فلاش وتعريف وفك شبكات وحل مشاكل السوفتوير.", 92, 20),
            Seed("عمر فاروق", "201000000006", "صيانة لابتوب وويندوز", S, "الجيزة - فيصل", "تثبيت ويندوز واسترجاع بيانات وإزالة الفيروسات.", 66, 15),
            Seed("سارة محمد", "201000000007", "تطوير تطبيقات أندرويد", S, "القاهرة - التجمع", "مطورة تطبيقات موبايل وويب.", 48, 10),
            Seed("طارق نبيل", "201000000008", "برمجة وشبكات", S, "المنصورة - وسط البلد", "برمجة أنظمة صغيرة وإعداد شبكات المكاتب.", 0, 0)
        )
        for (s in list) {
            val cv = ContentValues().apply {
                put("name", s.name)
                put("phone", s.phone)
                put("password", hash("123456"))
                put("specialty", s.specialty)
                put("type", s.type)
                put("address", s.address)
                put("bio", s.bio)
                put("rating_sum", s.sum)
                put("rating_count", s.count)
            }
            db.insert(TABLE, null, cv)
        }
    }

    /** يسجل فنياً جديداً. يعيد -1 إذا كان رقم الهاتف مسجلاً مسبقاً. */
    fun register(
        name: String, phone: String, password: String,
        specialty: String, type: String, address: String, bio: String
    ): Long {
        val cv = ContentValues().apply {
            put("name", name)
            put("phone", phone)
            put("password", hash(password))
            put("specialty", specialty)
            put("type", type)
            put("address", address)
            put("bio", bio)
        }
        return writableDatabase.insert(TABLE, null, cv)
    }

    fun login(phone: String, password: String): Technician? {
        readableDatabase.query(
            TABLE, null, "phone=? AND password=?",
            arrayOf(phone, hash(password)), null, null, null
        ).use { c ->
            return if (c.moveToFirst()) fromCursor(c) else null
        }
    }

    fun getById(id: Long): Technician? {
        if (id <= 0) return null
        readableDatabase.query(
            TABLE, null, "id=?", arrayOf(id.toString()), null, null, null
        ).use { c ->
            return if (c.moveToFirst()) fromCursor(c) else null
        }
    }

    fun getAll(type: String?, query: String?): List<Technician> {
        val conditions = mutableListOf<String>()
        val args = mutableListOf<String>()
        if (type != null) {
            conditions.add("type=?")
            args.add(type)
        }
        if (!query.isNullOrBlank()) {
            conditions.add("(name LIKE ? OR specialty LIKE ? OR address LIKE ?)")
            val q = "%${query.trim()}%"
            repeat(3) { args.add(q) }
        }
        val result = mutableListOf<Technician>()
        readableDatabase.query(
            TABLE, null,
            if (conditions.isEmpty()) null else conditions.joinToString(" AND "),
            if (args.isEmpty()) null else args.toTypedArray(),
            null, null,
            "(CASE WHEN rating_count=0 THEN 0 ELSE rating_sum*1.0/rating_count END) DESC, name ASC"
        ).use { c ->
            while (c.moveToNext()) result.add(fromCursor(c))
        }
        return result
    }

    /** يضيف تقييماً (1..5). إذا كان العميل قد قيّم من قبل يتم استبدال تقييمه القديم. */
    fun rate(id: Long, newRating: Int, oldRating: Int?) {
        val db = writableDatabase
        if (oldRating != null && oldRating > 0) {
            db.execSQL(
                "UPDATE $TABLE SET rating_sum = rating_sum - ? + ? WHERE id = ?",
                arrayOf<Any>(oldRating, newRating, id)
            )
        } else {
            db.execSQL(
                "UPDATE $TABLE SET rating_sum = rating_sum + ?, rating_count = rating_count + 1 WHERE id = ?",
                arrayOf<Any>(newRating, id)
            )
        }
    }

    private fun fromCursor(c: Cursor) = Technician(
        id = c.getLong(c.getColumnIndexOrThrow("id")),
        name = c.getString(c.getColumnIndexOrThrow("name")),
        phone = c.getString(c.getColumnIndexOrThrow("phone")),
        specialty = c.getString(c.getColumnIndexOrThrow("specialty")),
        type = c.getString(c.getColumnIndexOrThrow("type")),
        address = c.getString(c.getColumnIndexOrThrow("address")),
        bio = c.getString(c.getColumnIndexOrThrow("bio")),
        ratingSum = c.getInt(c.getColumnIndexOrThrow("rating_sum")),
        ratingCount = c.getInt(c.getColumnIndexOrThrow("rating_count"))
    )

    private fun hash(password: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(("frotta_fils:$password").toByteArray())
            .joinToString("") { "%02x".format(it) }

    companion object {
        private const val DB_NAME = "frotta_fils.db"
        private const val DB_VERSION = 1
        private const val TABLE = "technicians"
    }
}
