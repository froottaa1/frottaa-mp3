package com.frottafils.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.frottafils.app.data.DbHelper
import com.frottafils.app.data.Technician
import com.frottafils.app.databinding.ActivityMainBinding
import com.frottafils.app.util.Session

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnClient.setOnClickListener {
            startActivity(Intent(this, ClientActivity::class.java))
        }
        binding.btnTech.setOnClickListener { openTechnicianArea(Technician.TYPE_HARDWARE) }
        binding.btnSoftware.setOnClickListener { openTechnicianArea(Technician.TYPE_SOFTWARE) }
    }

    /** إذا كان الفني مسجلاً دخوله بنفس النوع نفتح ملفه مباشرة، وإلا شاشة تسجيل الدخول */
    private fun openTechnicianArea(type: String) {
        val current = DbHelper(this).getById(Session.getTechId(this))
        if (current != null && current.type == type) {
            startActivity(Intent(this, ProfileActivity::class.java))
        } else {
            startActivity(
                Intent(this, LoginActivity::class.java)
                    .putExtra(LoginActivity.EXTRA_TYPE, type)
            )
        }
    }
}
