package com.frottafils.app

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.frottafils.app.data.Technician
import com.frottafils.app.databinding.ItemTechnicianBinding

class TechnicianAdapter(
    private val onCall: (Technician) -> Unit,
    private val onWhatsApp: (Technician) -> Unit,
    private val onMap: (Technician) -> Unit,
    private val onRate: (Technician) -> Unit
) : RecyclerView.Adapter<TechnicianAdapter.VH>() {

    private var items: List<Technician> = emptyList()

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<Technician>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemTechnicianBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemTechnicianBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val t = items[position]
        val ctx = holder.b.root.context
        with(holder.b) {
            tvName.text = t.name
            tvType.setText(
                if (t.type == Technician.TYPE_SOFTWARE) R.string.badge_software
                else R.string.badge_hardware
            )
            tvSpecialty.text = t.specialty
            tvAddress.text = t.address
            ratingBar.rating = t.rating
            tvRating.text = if (t.ratingCount == 0) {
                ctx.getString(R.string.no_ratings)
            } else {
                ctx.getString(R.string.rating_fmt, t.rating, t.ratingCount)
            }
            btnCall.setOnClickListener { onCall(t) }
            btnWhatsapp.setOnClickListener { onWhatsApp(t) }
            btnMap.setOnClickListener { onMap(t) }
            btnRate.setOnClickListener { onRate(t) }
        }
    }
}
