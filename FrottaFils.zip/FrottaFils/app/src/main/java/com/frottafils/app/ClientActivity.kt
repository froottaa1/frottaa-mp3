package com.frottafils.app

import android.os.Bundle
import android.view.View
import android.widget.RatingBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import com.frottafils.app.data.DbHelper
import com.frottafils.app.data.Technician
import com.frottafils.app.databinding.ActivityClientBinding
import com.frottafils.app.util.Actions
import com.frottafils.app.util.Session
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class ClientActivity : AppCompatActivity() {

    private lateinit var binding: ActivityClientBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: TechnicianAdapter
    private var typeFilter: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityClientBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DbHelper(this)

        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = TechnicianAdapter(
            onCall = { Actions.call(this, it.phone) },
            onWhatsApp = { Actions.whatsapp(this, it.phone) },
            onMap = { Actions.map(this, it.address) },
            onRate = { showRateDialog(it) }
        )
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.chipGroup.setOnCheckedStateChangeListener { _, checkedIds ->
            typeFilter = when (checkedIds.firstOrNull()) {
                R.id.chipHardware -> Technician.TYPE_HARDWARE
                R.id.chipSoftware -> Technician.TYPE_SOFTWARE
                else -> null
            }
            load()
        }
        binding.etSearch.doAfterTextChanged { load() }

        load()
    }

    private fun load() {
        val list = db.getAll(typeFilter, binding.etSearch.text?.toString())
        adapter.submit(list)
        binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showRateDialog(t: Technician) {
        val view = layoutInflater.inflate(R.layout.dialog_rate, null)
        val bar = view.findViewById<RatingBar>(R.id.rateBar)
        val old = Session.getMyRating(this, t.id)
        bar.rating = old.toFloat()

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.rate_title, t.name))
            .setView(view)
            .setPositiveButton(R.string.submit) { _, _ ->
                val value = bar.rating.toInt()
                if (value < 1) {
                    Toast.makeText(this, R.string.choose_rating, Toast.LENGTH_SHORT).show()
                } else {
                    db.rate(t.id, value, if (old > 0) old else null)
                    Session.setMyRating(this, t.id, value)
                    Toast.makeText(this, R.string.rate_thanks, Toast.LENGTH_SHORT).show()
                    load()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
