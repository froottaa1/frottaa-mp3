package com.frottafils.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.frottafils.app.data.DbHelper
import com.frottafils.app.data.Technician
import com.frottafils.app.databinding.ActivityProfileBinding
import com.frottafils.app.util.Session

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnLogout.setOnClickListener {
            Session.logout(this)
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        val tech = DbHelper(this).getById(Session.getTechId(this))
        if (tech == null) {
            finish()
            return
        }
        bind(tech)
    }

    private fun bind(t: Technician) {
        with(binding) {
            tvName.text = t.name
            tvType.setText(
                if (t.type == Technician.TYPE_SOFTWARE) R.string.badge_software
                else R.string.badge_hardware
            )
            tvSpecialty.text = t.specialty
            tvPhone.text = t.phone
            tvAddress.text = t.address
            tvBio.text = if (t.bio.isBlank()) getString(R.string.no_bio) else t.bio
            ratingBar.rating = t.rating
            tvRating.text = if (t.ratingCount == 0) {
                getString(R.string.no_ratings)
            } else {
                getString(R.string.rating_fmt, t.rating, t.ratingCount)
            }
        }
    }
}
