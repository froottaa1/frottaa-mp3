package com.frottafils.app.util

import android.content.Context

object Session {
    private const val PREFS = "frotta_prefs"
    private const val KEY_TECH_ID = "tech_id"

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getTechId(ctx: Context): Long = prefs(ctx).getLong(KEY_TECH_ID, -1L)

    fun setTechId(ctx: Context, id: Long) {
        prefs(ctx).edit().putLong(KEY_TECH_ID, id).apply()
    }

    fun logout(ctx: Context) {
        prefs(ctx).edit().remove(KEY_TECH_ID).apply()
    }

    /** تقييمي السابق لهذا الفني (0 = لم أقيّمه) */
    fun getMyRating(ctx: Context, techId: Long): Int =
        prefs(ctx).getInt("rated_$techId", 0)

    fun setMyRating(ctx: Context, techId: Long, rating: Int) {
        prefs(ctx).edit().putInt("rated_$techId", rating).apply()
    }
}
